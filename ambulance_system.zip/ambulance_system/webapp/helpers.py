"""Small helpers shared by the route modules."""

import hmac
import math
import secrets
import time
from functools import lru_cache, wraps

from flask import abort, flash, redirect, request, session, url_for


def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


def verify_csrf():
    """Reject any POST that does not carry this session's token."""
    if request.method == "POST":
        sent = request.form.get("csrf_token", "").encode()
        expected = session.get("_csrf", "").encode()
        if not expected or not hmac.compare_digest(sent, expected):
            abort(400)


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "username" not in session:
            flash("Please sign in to continue.", "error")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def field(name):
    """Form value with surrounding and repeated whitespace removed."""
    return " ".join(request.form.get(name, "").split())


class LoginThrottle:
    """Blocks a username/address pair after too many failed sign-ins."""

    def __init__(self, max_failures=5, window_seconds=300, clock=time.monotonic):
        self.max_failures = max_failures
        self.window = window_seconds
        self._clock = clock
        self._failures = {}

    def _recent(self, key):
        now = self._clock()
        recent = [t for t in self._failures.get(key, []) if now - t < self.window]
        self._failures[key] = recent
        return recent

    def blocked(self, key):
        return len(self._recent(key)) >= self.max_failures

    def record_failure(self, key):
        self._recent(key).append(self._clock())

    def reset(self, key):
        self._failures.pop(key, None)


COMPACT_ABOVE = 12          # maps with more locations than this use the compact drawing
VIEW = 800                  # compact drawing: square viewBox size
MARGIN_X, MARGIN_Y = 120, 50


@lru_cache(maxsize=8)
def _stress_layout(names, roads, iterations=300, min_sep=0.05):
    """Stress-majorization layout in the unit square: on-screen distances approximate real
    road distances, so neighbouring places sit close together. Deterministic (fixed start)."""
    n = len(names)
    index = {name: i for i, name in enumerate(names)}
    inf = float("inf")
    dist = [[0.0 if i == j else inf for j in range(n)] for i in range(n)]
    for a, b, w in roads:
        i, j = index[a], index[b]
        dist[i][j] = dist[j][i] = min(dist[i][j], w)
    for k in range(n):                                   # Floyd-Warshall: all-pairs road distance
        for i in range(n):
            dik = dist[i][k]
            if dik == inf:
                continue
            for j in range(n):
                if dik + dist[k][j] < dist[i][j]:
                    dist[i][j] = dik + dist[k][j]
    longest = max((d for row in dist for d in row if d != inf), default=1.0) or 1.0
    target = [[(d if d != inf else longest * 1.5) / longest for d in row] for row in dist]

    pos = [[0.5 + 0.5 * math.cos(2 * math.pi * i / n), 0.5 + 0.5 * math.sin(2 * math.pi * i / n)]
           for i in range(n)]
    for _ in range(iterations):
        for i in range(n):
            sx = sy = sw = 0.0
            for j in range(n):
                if i == j:
                    continue
                dx, dy = pos[i][0] - pos[j][0], pos[i][1] - pos[j][1]
                length = max(math.hypot(dx, dy), 1e-9)
                weight = target[i][j] ** -2
                sx += weight * (pos[j][0] + target[i][j] * dx / length)
                sy += weight * (pos[j][1] + target[i][j] * dy / length)
                sw += weight
            pos[i][0], pos[i][1] = sx / sw, sy / sw

    for _ in range(150):                                 # push crowded nodes apart
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                dx, dy = pos[i][0] - pos[j][0], pos[i][1] - pos[j][1]
                length = math.hypot(dx, dy)
                if length < min_sep:
                    if length < 1e-9:
                        dx, dy, length = 1.0, 0.0, 1.0
                    push = (min_sep - length) / 2
                    ux, uy = dx / length, dy / length
                    pos[i][0] += ux * push; pos[i][1] += uy * push
                    pos[j][0] -= ux * push; pos[j][1] -= uy * push
                    moved = True
        if not moved:
            break

    xs, ys = [p[0] for p in pos], [p[1] for p in pos]
    span_x = (max(xs) - min(xs)) or 1.0                  # fill the drawing area on both axes
    span_y = (max(ys) - min(ys)) or 1.0
    return {name: ((pos[i][0] - min(xs)) / span_x, (pos[i][1] - min(ys)) / span_y)
            for name, i in index.items()}


CHAR_W, LABEL_H = 7.4, 17                  # approximate label size in the drawing's units


def _label_box(name, x, y):
    """Bounding box of a dot plus its side label (labels point toward the centre)."""
    width = CHAR_W * len(name) + 14
    if x < VIEW / 2:
        return x - 9, y - LABEL_H / 2, x + width, y + LABEL_H / 2
    return x - width, y - LABEL_H / 2, x + 9, y + LABEL_H / 2


@lru_cache(maxsize=8)
def _compact_points(names, roads):
    """Pixel positions for a large map: stress layout, then nudge nodes apart until no two
    labels overlap."""
    unit = _stress_layout(names, roads)
    points = {name: [MARGIN_X + ux * (VIEW - 2 * MARGIN_X), MARGIN_Y + uy * (VIEW - 2 * MARGIN_Y)]
              for name, (ux, uy) in unit.items()}
    for _ in range(400):
        moved = False
        for i, a in enumerate(names):
            for b in names[i + 1:]:
                ax0, ay0, ax1, ay1 = _label_box(a, *points[a])
                bx0, by0, bx1, by1 = _label_box(b, *points[b])
                overlap_x = min(ax1, bx1) - max(ax0, bx0)
                overlap_y = min(ay1, by1) - max(ay0, by0)
                if overlap_x > 0 and overlap_y > 0:
                    moved = True
                    if overlap_y <= overlap_x:                       # separate vertically
                        shift = overlap_y / 2 + 1
                        sign = 1 if points[a][1] >= points[b][1] else -1
                        points[a][1] += sign * shift
                        points[b][1] -= sign * shift
                    else:                                            # separate horizontally
                        shift = overlap_x / 2 + 1
                        sign = 1 if points[a][0] >= points[b][0] else -1
                        points[a][0] += sign * shift
                        points[b][0] -= sign * shift
        for p in points.values():                                    # stay inside the drawing
            p[0] = min(max(p[0], 25), VIEW - 25)
            p[1] = min(max(p[1], 25), VIEW - 25)
        if not moved:
            break
    return {name: (round(x, 1), round(y, 1)) for name, (x, y) in points.items()}


def layout_graph(graph, highlight_path=()):
    """Everything the road-map template needs to draw the network as SVG.

    Small maps: nodes on a circle with the name inside. Large maps ("compact"): a force layout
    with small dots and side labels, and road lengths shown only on the highlighted route.
    Nodes and roads on `highlight_path` are flagged so the route stands out."""
    names = tuple(graph.locations())
    roads = graph.roads()
    compact = len(names) > COMPACT_ABOVE
    if compact:
        size_x = size_y = VIEW
        points = _compact_points(names, tuple(roads))
    else:
        size_x = size_y = 400
        n = max(len(names), 1)
        points = {name: (round(200 + 150 * math.cos(2 * math.pi * i / n - math.pi / 2), 1),
                         round(200 + 150 * math.sin(2 * math.pi * i / n - math.pi / 2), 1))
                  for i, name in enumerate(names)}
    hot_nodes = set(highlight_path)
    hot_edges = {frozenset(pair) for pair in zip(highlight_path, highlight_path[1:])}
    nodes = []
    for name, (x, y) in points.items():
        on_right_half = x < size_x / 2
        nodes.append({"name": name, "x": x, "y": y, "hot": name in hot_nodes,
                      "label_x": x + (10 if on_right_half else -10),
                      "anchor": "start" if on_right_half else "end"})
    edges = []
    for a, b, d in roads:
        (x1, y1), (x2, y2) = points[a], points[b]
        length = math.hypot(x2 - x1, y2 - y1) or 1
        nudge = 11 if compact else 0                      # perpendicular offset
        edges.append({"x1": x1, "y1": y1, "x2": x2, "y2": y2,
                      "mx": round((x1 + x2) / 2 - (y2 - y1) / length * nudge, 1),
                      "my": round((y1 + y2) / 2 + (x2 - x1) / length * nudge, 1),
                      "distance": d, "hot": frozenset((a, b)) in hot_edges})
    return {"nodes": nodes, "edges": edges, "compact": compact, "size": size_x}
