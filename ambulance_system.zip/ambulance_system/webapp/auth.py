"""Operator accounts: register, sign in, sign out."""

import re

from flask import flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from ems.errors import ValidationError
from ems.validators import clean_text

from .helpers import LoginThrottle, field

USERNAME_RE = re.compile(r"^[a-z0-9_.]{3,30}$")
MIN_PASSWORD_LENGTH = 6


def register_auth(app, store):
    throttle = LoginThrottle()

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if "username" in session:
            return redirect(url_for("dashboard"))
        if request.method == "POST":
            username = field("username").lower()
            password = request.form.get("password", "")
            try:
                full_name = clean_text(field("full_name"), "Full name")
                if not USERNAME_RE.match(username):
                    raise ValidationError("Username must be 3-30 characters: letters, digits, '_' or '.'.")
                if len(password) < MIN_PASSWORD_LENGTH:
                    raise ValidationError(f"Password must be at least {MIN_PASSWORD_LENGTH} characters.")
                if password != request.form.get("confirm_password", ""):
                    raise ValidationError("Passwords do not match.")
                with store.write():
                    if username in store.users:
                        raise ValidationError("That username is already taken.")
                    store.users[username] = {"full_name": full_name,
                                             "password_hash": generate_password_hash(password)}
            except ValidationError as exc:
                flash(str(exc), "error")
                return redirect(url_for("register"))
            flash("Account created. Please sign in.", "success")
            return redirect(url_for("login"))
        return render_template("register.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if "username" in session:
            return redirect(url_for("dashboard"))
        if request.method == "POST":
            username = field("username").lower()
            key = (request.remote_addr, username)
            if throttle.blocked(key):
                flash("Too many failed attempts. Please wait a few minutes and try again.", "error")
                return redirect(url_for("login"))
            with store.read():
                user = store.users.get(username)
            if user and check_password_hash(user["password_hash"], request.form.get("password", "")):
                throttle.reset(key)
                session.clear()                                   # fresh session on sign-in
                session["username"] = username
                session["full_name"] = user["full_name"]
                flash(f"Signed in as {user['full_name']}.", "success")
                return redirect(url_for("dashboard"))
            throttle.record_failure(key)
            flash("Invalid username or password.", "error")
            return redirect(url_for("login"))
        return render_template("login.html")

    @app.post("/logout")
    def logout():
        session.clear()
        flash("You have been signed out.", "success")
        return redirect(url_for("login"))

    @app.route("/")
    def home():
        return redirect(url_for("dashboard") if "username" in session else url_for("login"))
