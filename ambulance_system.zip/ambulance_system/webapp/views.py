"""Console pages. Each route is a thin wrapper around the EmergencyAmbulanceSystem."""

from flask import abort, flash, redirect, render_template, request, url_for

from ems.errors import EMSError, NotFoundError
from ems.models import EmergencyStatus, Severity

from .helpers import field, layout_graph, login_required


def register_views(app, store):
    def failed(exc, endpoint, **values):
        flash(str(exc), "error")
        return redirect(url_for(endpoint, **values))

    # ------------------------------------------------------------ dashboard
    @app.route("/dashboard")
    @login_required
    def dashboard():
        with store.read() as s:
            stats = s.stats()
            queue = s.priority_snapshot()[:6]
            active = [(d, s.find_emergency(d.emergency_id), s.find_ambulance(d.ambulance_id))
                      for d in s.dispatches if d.completed_at is None]
            fleet = s.fleet_by_availability()
        return render_template("dashboard.html", stats=stats, queue=queue, active=active, fleet=fleet)

    # ------------------------------------------------------------ emergencies (Modules 1-2)
    @app.route("/emergencies", methods=["GET", "POST"])
    @login_required
    def emergencies():
        if request.method == "POST":
            try:
                with store.write() as s:
                    e = s.register_emergency(
                        field("patient_name"), field("age"), field("contact"),
                        field("emergency_type"), field("location"), field("severity"))
                flash(f"Emergency #{e.id} registered for {e.patient_name} ({e.severity.label}). "
                      f"Added to the intake queue.", "success")
            except EMSError as exc:
                flash(str(exc), "error")
            return redirect(url_for("emergencies"))
        with store.read() as s:
            return render_template(
                "emergencies.html", intake=s.intake_snapshot(), queue=s.priority_snapshot(),
                locations=s.graph.locations(), severities=list(Severity))

    @app.post("/emergencies/triage")
    @login_required
    def triage():
        with store.write() as s:
            moved = s.triage()
        flash(f"{moved} request(s) moved into the priority queue." if moved
              else "The intake queue is already empty.", "success")
        return redirect(url_for("emergencies"))

    @app.route("/records")
    @login_required
    def records():
        query = " ".join(request.args.get("q", "").split())
        with store.read() as s:
            try:
                if not query:
                    rows = s.emergencies_by_priority()                       # selection sort
                elif query.lstrip("#").isdigit():
                    rows = [s.find_emergency(int(query.lstrip("#")))]        # linear search by id
                else:
                    rows = s.search_emergencies(query)                       # linear search by name
            except NotFoundError:
                rows = []
        return render_template("records.html", rows=rows, query=query, Status=EmergencyStatus)

    @app.post("/emergencies/<int:eid>/cancel")
    @login_required
    def cancel_emergency(eid):
        try:
            with store.write() as s:
                s.cancel_emergency(eid)
            flash(f"Emergency #{eid} cancelled.", "success")
        except EMSError as exc:
            flash(str(exc), "error")
        return redirect(url_for("emergencies"))

    # ------------------------------------------------------------ dispatch (Modules 4 and 6)
    @app.post("/dispatch")
    @login_required
    def dispatch():
        try:
            with store.write() as s:
                result = s.dispatch_next()
        except EMSError as exc:
            return failed(exc, "emergencies")
        r = result.record
        app.logger.info("Dispatched %s to emergency #%s via %s (%s km)",
                        result.ambulance.vehicle_no, result.emergency.id, r.route_text, r.distance)
        flash(f"Ambulance {result.ambulance.vehicle_no} dispatched to {result.emergency.patient_name} "
              f"via {r.route_text} ({r.distance} km).", "success")
        if result.skipped:
            ids = ", ".join(f"#{e.id}" for e in result.skipped)
            flash(f"Higher-priority emergencies {ids} could not be reached by any free ambulance "
                  f"and remain pending.", "error")
        return redirect(url_for("history"))

    @app.post("/emergencies/<int:eid>/complete")
    @login_required
    def complete_emergency(eid):
        try:
            with store.write() as s:
                s.complete_dispatch(eid)
            flash(f"Emergency #{eid} completed. The ambulance is available again.", "success")
        except EMSError as exc:
            flash(str(exc), "error")
        return redirect(url_for("history"))

    @app.route("/history")
    @login_required
    def history():
        with store.read() as s:
            rows = [(d, s.find_emergency(d.emergency_id), s.find_ambulance(d.ambulance_id))
                    for d in reversed(s.dispatches)]
        return render_template("history.html", rows=rows)

    # ------------------------------------------------------------ fleet (Module 3)
    @app.route("/ambulances", methods=["GET", "POST"])
    @login_required
    def ambulances():
        if request.method == "POST":
            try:
                with store.write() as s:
                    a = s.register_ambulance(field("driver"), field("vehicle_no"), field("location"))
                flash(f"Ambulance {a.vehicle_no} added to the fleet at {a.location}.", "success")
            except EMSError as exc:
                flash(str(exc), "error")
            return redirect(url_for("ambulances"))
        with store.read() as s:
            return render_template("ambulances.html", fleet=s.fleet_by_availability(),
                                   locations=s.graph.locations())

    @app.post("/ambulances/<int:aid>/free")
    @login_required
    def free_ambulance(aid):
        try:
            with store.write() as s:
                s.mark_available(aid)
            flash("Ambulance marked as available.", "success")
        except EMSError as exc:
            flash(str(exc), "error")
        return redirect(url_for("ambulances"))

    @app.post("/ambulances/<int:aid>/delete")
    @login_required
    def delete_ambulance(aid):
        try:
            with store.write() as s:
                a = s.remove_ambulance(aid)
            flash(f"Ambulance {a.vehicle_no} removed.", "success")
        except NotFoundError:
            abort(404)
        except EMSError as exc:
            flash(str(exc), "error")
        return redirect(url_for("ambulances"))

    # ------------------------------------------------------------ road map (Modules 5-6)
    @app.route("/roads", methods=["GET", "POST"])
    @login_required
    def roads():
        if request.method == "POST":
            try:
                with store.write() as s:
                    a, b = s.add_road(field("loc1"), field("loc2"), field("distance"))
                flash(f"Road added: {a} - {b}.", "success")
            except EMSError as exc:
                flash(str(exc), "error")
            return redirect(url_for("roads"))

        start, end = field_arg("from"), field_arg("to")
        route = None
        with store.read() as s:
            if start and end:
                try:
                    path, distance = s.shortest_route(start, end)
                    legs = [(a, b, s.graph.road_distance(a, b)) for a, b in zip(path, path[1:])]
                    route = {"path": path, "distance": distance, "legs": legs}
                except EMSError as exc:
                    flash(str(exc), "error")
            diagram = layout_graph(s.graph, route["path"] if route else ())
            return render_template("roads.html", roads=s.graph.roads(), diagram=diagram,
                                   locations=s.graph.locations(), route=route, start=start, end=end)

    @app.post("/roads/delete")
    @login_required
    def delete_road():
        try:
            with store.write() as s:
                a, b = s.remove_road(field("loc1"), field("loc2"))
            flash(f"Road {a} - {b} removed.", "success")
        except EMSError as exc:
            flash(str(exc), "error")
        return redirect(url_for("roads"))

    def field_arg(name):
        return " ".join(request.args.get(name, "").split())
