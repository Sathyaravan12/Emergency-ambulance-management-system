// Confirmation prompts for destructive actions. The message lives in a data attribute,
// so patient names and other user text are never placed inside JavaScript code.
document.addEventListener("submit", function (event) {
  var message = event.target.getAttribute("data-confirm");
  if (message && !window.confirm(message)) {
    event.preventDefault();
  }
});
