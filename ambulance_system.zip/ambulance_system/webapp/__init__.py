"""Web front end for the Emergency Ambulance Management System."""

import os
import secrets

from flask import Flask, render_template, session
from werkzeug.security import generate_password_hash

from .auth import register_auth
from .helpers import csrf_token, verify_csrf
from .store import Store
from .views import register_views

ERROR_MESSAGES = {
    400: "The request could not be processed. Go back, refresh the page and try again.",
    404: "That page does not exist.",
    405: "That action is not allowed on this page.",
    500: "Something went wrong on our side. Your data is safe; please try again.",
}


def _load_secret_key(instance_path):
    """SECRET_KEY from the environment, else a random key kept in instance/."""
    if os.environ.get("SECRET_KEY"):
        return os.environ["SECRET_KEY"]
    key_file = os.path.join(instance_path, "secret.key")
    if os.path.exists(key_file):
        with open(key_file) as fh:
            return fh.read().strip()
    key = secrets.token_hex(32)
    with open(key_file, "w") as fh:
        fh.write(key)
    return key


def create_app(test_config=None):
    app = Flask(__name__, instance_path=os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), "instance"))
    os.makedirs(app.instance_path, exist_ok=True)
    app.config.from_mapping(
        DATA_FILE=os.environ.get("EMS_DATA_FILE", os.path.join(app.instance_path, "data.json")),
        SEED_DEMO_DATA=True,
        DEMO_DATASET=os.environ.get("EMS_DEMO_DATASET", "city"),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
    )
    if test_config:
        app.config.update(test_config)
    if not app.config.get("SECRET_KEY"):
        app.config["SECRET_KEY"] = _load_secret_key(app.instance_path)

    store = Store(
        app.config["DATA_FILE"],
        seed_demo_data=app.config["SEED_DEMO_DATA"],
        demo_password_hash=generate_password_hash("admin123") if app.config["SEED_DEMO_DATA"] else None,
        demo_dataset=app.config["DEMO_DATASET"],
    )
    app.extensions["store"] = store

    app.before_request(verify_csrf)

    @app.after_request
    def security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        return response

    @app.context_processor
    def inject_globals():
        return {"current_user": session.get("full_name"), "csrf_token": csrf_token}

    @app.template_filter("dt")
    def format_time(moment):
        return moment.strftime("%d %b %Y, %H:%M") if moment else "-"

    register_auth(app, store)
    register_views(app, store)

    def render_error(error):
        code = getattr(error, "code", 500)
        return render_template("error.html", code=code,
                               message=ERROR_MESSAGES.get(code, ERROR_MESSAGES[500])), code

    for code in ERROR_MESSAGES:
        app.register_error_handler(code, render_error)
    return app
