"""
Thread-safe holder for the live system and the operator accounts.

All requests share one EmergencyAmbulanceSystem. A lock serialises access so
two operators dispatching at the same moment can never get the same ambulance.
After every successful write the state is saved to a JSON file.
"""

import threading
from contextlib import contextmanager

from ems import persistence
from ems.sample_data import DEFAULT_DATASET, load_demo
from ems.system import EmergencyAmbulanceSystem


class Store:
    def __init__(self, path, seed_demo_data=True, demo_password_hash=None, demo_dataset=DEFAULT_DATASET):
        self.path = path
        self.lock = threading.RLock()
        self.system = EmergencyAmbulanceSystem()
        self.users = {}                                   # username -> {full_name, password_hash}

        data = persistence.load_json(path)
        if data is not None:
            persistence.restore(self.system, data.get("system", {}))
            self.users = dict(data.get("users", {}))
        elif seed_demo_data:
            load_demo(self.system, demo_dataset)
            if demo_password_hash:
                self.users["admin"] = {"full_name": "Control Room Admin",
                                       "password_hash": demo_password_hash}
            self.save()

    @contextmanager
    def read(self):
        """Exclusive access without saving."""
        with self.lock:
            yield self.system

    @contextmanager
    def write(self):
        """Exclusive access; the state is saved if the block finishes without an error."""
        with self.lock:
            yield self.system
            self.save()

    def save(self):
        persistence.save_json(self.path, {"system": persistence.dump(self.system), "users": self.users})
