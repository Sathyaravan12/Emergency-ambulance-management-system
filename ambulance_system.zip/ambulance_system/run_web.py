"""
Start the web application:   python3 run_web.py     ->  http://127.0.0.1:5000

Environment variables (all optional):
    EMS_DATA_FILE  where operator accounts and system data are saved
    SECRET_KEY     session signing key (otherwise generated and kept in instance/)
    HOST, PORT     server address;  FLASK_DEBUG=1 turns on debug mode (development only)
"""

import logging
import os

from webapp import create_app

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    create_app().run(
        host=os.environ.get("HOST", "127.0.0.1"),
        port=int(os.environ.get("PORT", "5000")),
        debug=os.environ.get("FLASK_DEBUG") == "1",
        threaded=True,
    )
