"""
Optional JSON snapshots of the system state (standard library only).

The core system works purely in memory, as the proposal specifies. The web
application uses this module so its data survives a restart, without needing
a database. Files are written atomically: a crash mid-save can never leave a
half-written file behind.
"""

import json
import os
import tempfile
from datetime import datetime

from .errors import PersistenceError
from .models import (Ambulance, AmbulanceStatus, DispatchRecord, Emergency,
                     EmergencyStatus, Severity)

SNAPSHOT_VERSION = 1
_TIME = "%Y-%m-%dT%H:%M:%S"


def _stamp(moment):
    return moment.strftime(_TIME) if moment else None


def _parse(text):
    return datetime.strptime(text, _TIME) if text else None


def dump(system):
    """The whole system as plain JSON-compatible data."""
    return {
        "version": SNAPSHOT_VERSION,
        "roads": [[a, b, d] for a, b, d in system.graph.roads()],
        "ambulances": [
            {"id": a.id, "driver": a.driver, "vehicle_no": a.vehicle_no,
             "location": a.location, "status": a.status.value}
            for a in system.ambulances
        ],
        "emergencies": [
            {"id": e.id, "patient_name": e.patient_name, "age": e.age, "contact": e.contact,
             "emergency_type": e.emergency_type, "location": e.location,
             "severity": int(e.severity), "status": e.status.value,
             "reported_at": _stamp(e.reported_at)}
            for e in system.emergencies
        ],
        "dispatches": [
            {"id": d.id, "emergency_id": d.emergency_id, "ambulance_id": d.ambulance_id,
             "route": d.route, "distance": d.distance,
             "dispatched_at": _stamp(d.dispatched_at), "completed_at": _stamp(d.completed_at)}
            for d in system.dispatches
        ],
        "intake_ids": [e.id for e in system.intake_queue],
        "counters": system.counters(),
    }


def restore(system, data):
    """Fill an empty system from dump() output. Raises PersistenceError if malformed."""
    try:
        if data.get("version") != SNAPSHOT_VERSION:
            raise ValueError(f"unsupported snapshot version {data.get('version')!r}")
        for a, b, d in data["roads"]:
            system.graph.add_road(a, b, d)
        for r in data["ambulances"]:
            system.ambulances.append(Ambulance(
                r["id"], r["driver"], r["vehicle_no"], r["location"], AmbulanceStatus(r["status"])))
        by_id = {}
        for r in data["emergencies"]:
            e = Emergency(r["id"], r["patient_name"], r["age"], r["contact"], r["emergency_type"],
                          r["location"], Severity(r["severity"]), EmergencyStatus(r["status"]),
                          _parse(r["reported_at"]))
            system.emergencies.append(e)
            by_id[e.id] = e
        for r in data["dispatches"]:
            system.dispatches.append(DispatchRecord(
                r["id"], r["emergency_id"], r["ambulance_id"], list(r["route"]), r["distance"],
                _parse(r["dispatched_at"]), _parse(r["completed_at"])))
        # Pending requests are either still in the intake queue or already in the priority queue.
        intake = set(data["intake_ids"])
        for emergency_id in data["intake_ids"]:                  # preserves arrival order
            system.intake_queue.enqueue(by_id[emergency_id])
        for e in system.emergencies:
            if e.status is EmergencyStatus.PENDING and e.id not in intake:
                system.priority_queue.push(int(e.severity), e.id, e)
        system.set_counters(**data["counters"])
    except (KeyError, TypeError, ValueError, AttributeError) as exc:
        raise PersistenceError(f"The saved data is damaged or incompatible ({exc}).") from None


def save_json(path, payload):
    """Write JSON atomically (temp file + rename)."""
    folder = os.path.dirname(os.path.abspath(path))
    os.makedirs(folder, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=folder, prefix=".ems-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except OSError as exc:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise PersistenceError(f"Could not save data to {path}: {exc}") from None


def load_json(path):
    """Read a JSON file. Returns None if it does not exist yet."""
    if not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        raise PersistenceError(f"Could not read {path}: {exc}") from None
