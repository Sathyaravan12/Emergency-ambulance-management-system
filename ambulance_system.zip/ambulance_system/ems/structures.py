"""
Linear data structures built from scratch (no collections / heapq).

    LinkedList     Module 3  maintains ambulance records dynamically
    Queue          Module 1  pending emergency requests, first in first out
    MinHeap        shared binary heap used by PriorityQueue and Dijkstra
    PriorityQueue  Module 2  most critical emergency first
"""

from itertools import count


class _Node:
    __slots__ = ("value", "next")

    def __init__(self, value):
        self.value = value
        self.next = None


# ----------------------------------------------------------------
# LINKED LIST
# ----------------------------------------------------------------
class LinkedList:
    """Singly linked list with head and tail pointers.

    append / prepend / pop_front are O(1); remove and traversal are O(n).
    """

    def __init__(self, items=()):
        self._head = None
        self._tail = None
        self._size = 0
        for item in items:
            self.append(item)

    def append(self, value):
        node = _Node(value)
        if self._tail is None:
            self._head = self._tail = node
        else:
            self._tail.next = node
            self._tail = node
        self._size += 1

    def prepend(self, value):
        node = _Node(value)
        node.next = self._head
        self._head = node
        if self._tail is None:
            self._tail = node
        self._size += 1

    def pop_front(self):
        if self._head is None:
            raise IndexError("pop from an empty list")
        node = self._head
        self._head = node.next
        if self._head is None:
            self._tail = None
        self._size -= 1
        return node.value

    def peek_front(self):
        if self._head is None:
            raise IndexError("peek at an empty list")
        return self._head.value

    def remove_first(self, predicate):
        """Delete the first value for which predicate(value) is true.
        Returns True if something was removed."""
        prev, cur = None, self._head
        while cur is not None:
            if predicate(cur.value):
                self._unlink(prev, cur)
                return True
            prev, cur = cur, cur.next
        return False

    def remove_all(self, predicate):
        """Delete every matching value. Returns how many were removed."""
        removed = 0
        prev, cur = None, self._head
        while cur is not None:
            if predicate(cur.value):
                self._unlink(prev, cur)
                removed += 1
                cur = prev.next if prev is not None else self._head
            else:
                prev, cur = cur, cur.next
        return removed

    def _unlink(self, prev, cur):
        if prev is None:
            self._head = cur.next
        else:
            prev.next = cur.next
        if cur is self._tail:
            self._tail = prev
        self._size -= 1

    def is_empty(self):
        return self._size == 0

    def __len__(self):
        return self._size

    def __iter__(self):
        cur = self._head
        while cur is not None:
            yield cur.value
            cur = cur.next


# ----------------------------------------------------------------
# QUEUE
# ----------------------------------------------------------------
class Queue:
    """First-in, first-out queue stored in a linked list. All O(1) except remove_if."""

    def __init__(self, items=()):
        self._items = LinkedList(items)

    def enqueue(self, value):
        self._items.append(value)

    def dequeue(self):
        if self._items.is_empty():
            raise IndexError("dequeue from an empty queue")
        return self._items.pop_front()

    def peek(self):
        if self._items.is_empty():
            raise IndexError("peek at an empty queue")
        return self._items.peek_front()

    def remove_if(self, predicate):
        """Delete matching entries from anywhere in the queue (O(n))."""
        return self._items.remove_all(predicate)

    def is_empty(self):
        return self._items.is_empty()

    def __len__(self):
        return len(self._items)

    def __iter__(self):
        return iter(self._items)


# ----------------------------------------------------------------
# BINARY MIN-HEAP
# ----------------------------------------------------------------
class MinHeap:
    """Array-backed binary min-heap. push/pop O(log n), peek O(1)."""

    def __init__(self):
        self._a = []

    def push(self, item):
        a = self._a
        a.append(item)
        i = len(a) - 1
        while i > 0:                                   # sift up
            parent = (i - 1) // 2
            if a[i] < a[parent]:
                a[i], a[parent] = a[parent], a[i]
                i = parent
            else:
                break

    def pop(self):
        a = self._a
        if not a:
            raise IndexError("pop from an empty heap")
        top, last = a[0], a.pop()
        if a:
            a[0] = last
            i, n = 0, len(a)
            while True:                                # sift down
                left, right, smallest = 2 * i + 1, 2 * i + 2, i
                if left < n and a[left] < a[smallest]:
                    smallest = left
                if right < n and a[right] < a[smallest]:
                    smallest = right
                if smallest == i:
                    break
                a[i], a[smallest] = a[smallest], a[i]
                i = smallest
        return top

    def peek(self):
        if not self._a:
            raise IndexError("peek at an empty heap")
        return self._a[0]

    def copy(self):
        clone = MinHeap()
        clone._a = list(self._a)
        return clone

    def __len__(self):
        return len(self._a)

    def __bool__(self):
        return bool(self._a)

    def __iter__(self):
        return iter(self._a)


# ----------------------------------------------------------------
# PRIORITY QUEUE
# ----------------------------------------------------------------
class PriorityQueue:
    """Lowest priority number first (severity 1 = most critical).
    Ties are broken by `order` (arrival number), so equal-severity
    emergencies are served first come, first served."""

    def __init__(self):
        self._heap = MinHeap()
        self._seq = count()

    def push(self, priority, order, payload):
        self._heap.push((priority, order, next(self._seq), payload))

    def pop(self):
        if not self._heap:
            raise IndexError("pop from an empty priority queue")
        return self._heap.pop()[3]

    def peek(self):
        if not self._heap:
            raise IndexError("peek at an empty priority queue")
        return self._heap.peek()[3]

    def ordered(self):
        """All payloads in priority order, without consuming the queue."""
        heap, result = self._heap.copy(), []
        while heap:
            result.append(heap.pop()[3])
        return result

    def remove_if(self, predicate):
        """Delete matching payloads and rebuild the heap. Returns the count removed."""
        kept = [entry for entry in self._heap if not predicate(entry[3])]
        removed = len(self._heap) - len(kept)
        rebuilt = MinHeap()
        for entry in kept:
            rebuilt.push(entry)
        self._heap = rebuilt
        return removed

    def is_empty(self):
        return not self._heap

    def __len__(self):
        return len(self._heap)
