"""Searching and sorting algorithms (Linear Search, Selection Sort)."""


def linear_search(items, predicate):
    """Scan items one by one; return the first match, or None."""
    for item in items:
        if predicate(item):
            return item
    return None


def linear_search_all(items, predicate):
    """Scan every item; return all matches in their original order."""
    return [item for item in items if predicate(item)]


def selection_sort(items, key=lambda x: x):
    """Return a new list sorted ascending by key using selection sort, O(n^2).
    Repeatedly selects the smallest remaining element and swaps it into place."""
    arr = list(items)
    for i in range(len(arr)):
        smallest = i
        for j in range(i + 1, len(arr)):
            if key(arr[j]) < key(arr[smallest]):
                smallest = j
        arr[i], arr[smallest] = arr[smallest], arr[i]
    return arr
