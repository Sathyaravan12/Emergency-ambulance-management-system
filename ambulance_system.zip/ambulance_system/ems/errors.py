"""Exceptions raised by the system. The console turns them into friendly messages."""


class EMSError(Exception):
    """Base class for all expected, user-facing errors."""


class ValidationError(EMSError):
    """Input is missing, malformed or out of range."""


class NotFoundError(EMSError):
    """A requested record does not exist."""


class OperationError(EMSError):
    """The action is not allowed in the current state."""


class PersistenceError(EMSError):
    """A saved data file could not be read or written."""
