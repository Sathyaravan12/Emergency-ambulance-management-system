"""Input validation shared by the console and the system layer."""

import math
import re

from .errors import ValidationError

MAX_TEXT = 60
MAX_DISTANCE_KM = 1000
_CONTACT_RE = re.compile(r"^\+?\d{7,15}$")
_VEHICLE_RE = re.compile(r"^[A-Z0-9][A-Z0-9 \-]{3,19}$")


def clean_text(value, label, max_len=MAX_TEXT):
    text = " ".join(str(value).split())
    if not text:
        raise ValidationError(f"{label} is required.")
    if len(text) > max_len:
        raise ValidationError(f"{label} must be at most {max_len} characters.")
    return text


def parse_age(value):
    try:
        age = int(str(value).strip())
    except ValueError:
        raise ValidationError("Age must be a whole number.") from None
    if not 0 <= age <= 120:
        raise ValidationError("Age must be between 0 and 120.")
    return age


def clean_contact(value):
    number = re.sub(r"[\s\-]", "", str(value))
    if not _CONTACT_RE.match(number):
        raise ValidationError("Contact number must have 7-15 digits (optional leading +).")
    return number


def clean_vehicle(value):
    vehicle = " ".join(str(value).upper().split())
    if not _VEHICLE_RE.match(vehicle):
        raise ValidationError("Vehicle number must be 4-20 characters: letters, digits, spaces or '-'.")
    return vehicle


def parse_distance(value):
    try:
        distance = float(str(value).strip())
    except ValueError:
        raise ValidationError("Distance must be a number.") from None
    if not math.isfinite(distance) or not 0 < distance <= MAX_DISTANCE_KM:
        raise ValidationError(f"Distance must be greater than 0 and at most {MAX_DISTANCE_KM} km.")
    return round(distance, 2)
