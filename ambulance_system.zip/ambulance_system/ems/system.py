"""
The Emergency Ambulance Management System: all business rules live here.

The console (cli.py) only collects input and prints results, so everything
in this class can be tested without a terminal.

Workflow (matches the proposal flowchart):
    register emergency -> Queue (intake)
    triage             -> Priority Queue (ordered by severity)
    dispatch           -> take the most critical request, linear-search the fleet
                          for the nearest Available ambulance (Dijkstra distance),
                          dispatch it, and update its status.
    If no ambulance is available the request stays pending.
"""

from datetime import datetime

from .algorithms import linear_search, linear_search_all, selection_sort
from .errors import NotFoundError, OperationError, ValidationError
from .graph import INF, Graph
from .models import (Ambulance, AmbulanceStatus, DispatchRecord, DispatchResult,
                     Emergency, EmergencyStatus, Severity)
from .structures import LinkedList, PriorityQueue, Queue
from .validators import clean_contact, clean_text, clean_vehicle, parse_age, parse_distance


class EmergencyAmbulanceSystem:
    def __init__(self, clock=datetime.now):
        self._clock = clock
        self.graph = Graph()                    # Module 5
        self.ambulances = LinkedList()          # Module 3
        self.intake_queue = Queue()             # Module 1
        self.priority_queue = PriorityQueue()   # Module 2
        self.emergencies = []                   # every record, in arrival order
        self.dispatches = []                    # dispatch history
        self._emergency_seq = 0
        self._ambulance_seq = 0
        self._dispatch_seq = 0

    # ------------------------------------------------------------
    # State snapshots (used by persistence.py)
    # ------------------------------------------------------------
    def counters(self):
        return {"emergency": self._emergency_seq, "ambulance": self._ambulance_seq,
                "dispatch": self._dispatch_seq}

    def set_counters(self, emergency, ambulance, dispatch):
        self._emergency_seq, self._ambulance_seq, self._dispatch_seq = emergency, ambulance, dispatch

    # ------------------------------------------------------------
    # Locations and roads (Module 5)
    # ------------------------------------------------------------
    def add_road(self, loc1, loc2, distance):
        a = clean_text(loc1, "Location A", 40)
        b = clean_text(loc2, "Location B", 40)
        try:
            return self.graph.add_road(a, b, parse_distance(distance))
        except ValueError as exc:
            raise ValidationError(str(exc)) from None

    def remove_road(self, loc1, loc2):
        try:
            return self.graph.remove_road(loc1, loc2)
        except ValueError as exc:
            raise NotFoundError(str(exc)) from None

    def require_location(self, name):
        """Return the stored spelling of a known location, or raise ValidationError."""
        text = clean_text(name, "Location", 40)
        match = self.graph.resolve(text)
        if match is None:
            known = ", ".join(self.graph.locations()) or "none yet - add roads first"
            raise ValidationError(f"Unknown location '{text}'. Known locations: {known}.")
        return match

    def shortest_route(self, start, end):
        a, b = self.require_location(start), self.require_location(end)
        path, distance = self.graph.dijkstra(a, b)
        if path is None:
            raise NotFoundError(f"There is no route between {a} and {b}.")
        return path, distance

    # ------------------------------------------------------------
    # Emergencies (Modules 1 and 2)
    # ------------------------------------------------------------
    def register_emergency(self, patient_name, age, contact, emergency_type, location, severity):
        try:
            severity = Severity(int(severity))
        except (ValueError, TypeError):
            raise ValidationError("Severity must be 1 (critical), 2 (moderate) or 3 (minor).") from None
        emergency = Emergency(
            id=self._emergency_seq + 1,
            patient_name=clean_text(patient_name, "Patient name"),
            age=parse_age(age),
            contact=clean_contact(contact),
            emergency_type=clean_text(emergency_type, "Emergency type"),
            location=self.require_location(location),
            severity=severity,
            reported_at=self._clock(),
        )
        self._emergency_seq = emergency.id
        self.emergencies.append(emergency)
        self.intake_queue.enqueue(emergency)
        return emergency

    def triage(self):
        """Move every queued request into the priority queue. Returns how many moved."""
        moved = 0
        while not self.intake_queue.is_empty():
            e = self.intake_queue.dequeue()
            self.priority_queue.push(int(e.severity), e.id, e)
            moved += 1
        return moved

    def intake_snapshot(self):
        return list(self.intake_queue)

    def priority_snapshot(self):
        return self.priority_queue.ordered()

    def find_emergency(self, emergency_id):
        """Linear search for an emergency record by id."""
        found = linear_search(self.emergencies, lambda e: e.id == emergency_id)
        if found is None:
            raise NotFoundError(f"No emergency with id #{emergency_id}.")
        return found

    def search_emergencies(self, text):
        """Linear search by patient name (case-insensitive, partial match)."""
        needle = clean_text(text, "Search text").casefold()
        return linear_search_all(self.emergencies, lambda e: needle in e.patient_name.casefold())

    def emergencies_by_priority(self):
        """All records ordered by severity then arrival, using selection sort."""
        return selection_sort(self.emergencies, key=lambda e: (int(e.severity), e.id))

    def cancel_emergency(self, emergency_id):
        e = self.find_emergency(emergency_id)
        if e.status is not EmergencyStatus.PENDING:
            raise OperationError(f"Only pending emergencies can be cancelled (this one is {e.status.value}).")
        self.intake_queue.remove_if(lambda x: x.id == e.id)
        self.priority_queue.remove_if(lambda x: x.id == e.id)
        e.status = EmergencyStatus.CANCELLED
        return e

    # ------------------------------------------------------------
    # Ambulances (Module 3)
    # ------------------------------------------------------------
    def register_ambulance(self, driver, vehicle_no, location):
        vehicle = clean_vehicle(vehicle_no)
        if linear_search(self.ambulances, lambda a: a.vehicle_no == vehicle):
            raise ValidationError(f"Vehicle {vehicle} is already registered.")
        ambulance = Ambulance(
            id=self._ambulance_seq + 1,
            driver=clean_text(driver, "Driver name"),
            vehicle_no=vehicle,
            location=self.require_location(location),
        )
        self._ambulance_seq = ambulance.id
        self.ambulances.append(ambulance)
        return ambulance

    def find_ambulance(self, ambulance_id):
        found = linear_search(self.ambulances, lambda a: a.id == ambulance_id)
        if found is None:
            raise NotFoundError(f"No ambulance with id #{ambulance_id}.")
        return found

    def fleet_by_availability(self):
        """Available ambulances first, using selection sort."""
        return selection_sort(
            self.ambulances,
            key=lambda a: (0 if a.status is AmbulanceStatus.AVAILABLE else 1, a.id),
        )

    def remove_ambulance(self, ambulance_id):
        a = self.find_ambulance(ambulance_id)
        if a.status is not AmbulanceStatus.AVAILABLE:
            raise OperationError("An ambulance on duty cannot be removed. Complete its dispatch first.")
        if linear_search(self.dispatches, lambda d: d.ambulance_id == a.id):
            raise OperationError("This ambulance appears in the dispatch history and cannot be removed.")
        self.ambulances.remove_first(lambda x: x.id == a.id)
        return a

    def mark_available(self, ambulance_id):
        a = self.find_ambulance(ambulance_id)
        if a.status is AmbulanceStatus.AVAILABLE:
            raise OperationError("That ambulance is already available.")
        active = linear_search(self.dispatches, lambda d: d.ambulance_id == a.id and d.completed_at is None)
        if active:
            raise OperationError(
                f"Ambulance is serving emergency #{active.emergency_id}. Complete that dispatch instead.")
        a.status = AmbulanceStatus.AVAILABLE
        return a

    # ------------------------------------------------------------
    # Assignment and dispatch (Modules 4 and 6)
    # ------------------------------------------------------------
    def _nearest_available(self, location):
        """Linear search over the ambulance linked list; Dijkstra gives each distance."""
        best, best_path, best_dist = None, None, INF
        for amb in self.ambulances:                       # <- linear search
            if amb.status is AmbulanceStatus.AVAILABLE:
                path, dist = self.graph.dijkstra(amb.location, location)
                if path is not None and dist < best_dist:
                    best, best_path, best_dist = amb, path, dist
        return best, best_path, best_dist

    def dispatch_next(self):
        """Dispatch an ambulance to the most critical emergency that can be served.

        Emergencies nobody can currently reach stay pending, and never block
        the ones behind them."""
        self.triage()
        if self.priority_queue.is_empty():
            raise OperationError("There are no pending emergencies.")

        skipped, result = [], None
        while not self.priority_queue.is_empty():
            emergency = self.priority_queue.pop()
            ambulance, path, distance = self._nearest_available(emergency.location)
            if ambulance is None:
                skipped.append(emergency)
                continue
            ambulance.status = AmbulanceStatus.ON_DUTY
            ambulance.location = emergency.location
            emergency.status = EmergencyStatus.DISPATCHED
            self._dispatch_seq += 1
            record = DispatchRecord(self._dispatch_seq, emergency.id, ambulance.id,
                                    path, distance, self._clock())
            self.dispatches.append(record)
            result = DispatchResult(record, emergency, ambulance, [])
            break

        for e in skipped:                                  # put unserved requests back
            self.priority_queue.push(int(e.severity), e.id, e)
        if result is None:
            raise OperationError(
                "No available ambulance can currently reach any pending emergency. "
                "The requests stay pending.")
        result.skipped = skipped
        return result

    def complete_dispatch(self, emergency_id):
        e = self.find_emergency(emergency_id)
        record = linear_search(
            self.dispatches, lambda d: d.emergency_id == e.id and d.completed_at is None)
        if record is None:
            raise OperationError(f"Emergency #{e.id} has no active dispatch (status: {e.status.value}).")
        record.completed_at = self._clock()
        e.status = EmergencyStatus.COMPLETED
        self.find_ambulance(record.ambulance_id).status = AmbulanceStatus.AVAILABLE
        return record

    # ------------------------------------------------------------
    # Reporting
    # ------------------------------------------------------------
    def stats(self):
        fleet = list(self.ambulances)
        return {
            "locations": len(self.graph.adjacency),
            "roads": len(self.graph.roads()),
            "ambulances": len(fleet),
            "available": sum(a.status is AmbulanceStatus.AVAILABLE for a in fleet),
            "intake": len(self.intake_queue),
            "pending": sum(e.status is EmergencyStatus.PENDING for e in self.emergencies),
            "active": sum(e.status is EmergencyStatus.DISPATCHED for e in self.emergencies),
            "completed": sum(e.status is EmergencyStatus.COMPLETED for e in self.emergencies),
        }
