"""
Module 5 (Location and Road Management) and Module 6 (Shortest Route).

Locations are vertices and roads are weighted, undirected edges, stored
as an adjacency list. Dijkstra's algorithm is a greedy algorithm: at each
step it settles the closest unsettled location, which is why the first time
a location leaves the heap its distance is final.
"""

import math

from .structures import MinHeap

INF = float("inf")


class Graph:
    def __init__(self):
        self.adjacency = {}          # location -> list of (neighbour, distance)

    # ---------------- building ----------------
    def add_road(self, loc1, loc2, distance):
        if loc1.casefold() == loc2.casefold():
            raise ValueError("A road must connect two different locations.")
        if not isinstance(distance, (int, float)) or not math.isfinite(distance) or distance <= 0:
            raise ValueError("Road distance must be a positive, finite number.")
        loc1 = self.resolve(loc1) or loc1
        loc2 = self.resolve(loc2) or loc2
        if self.has_road(loc1, loc2):
            raise ValueError(f"A road between {loc1} and {loc2} already exists.")
        self.adjacency.setdefault(loc1, []).append((loc2, distance))
        self.adjacency.setdefault(loc2, []).append((loc1, distance))
        return loc1, loc2

    def remove_road(self, loc1, loc2):
        """Delete a road. Locations left with no roads are removed too."""
        a, b = self.resolve(loc1), self.resolve(loc2)
        if a is None or b is None or not self.has_road(a, b):
            raise ValueError("No such road.")
        self.adjacency[a] = [(n, d) for n, d in self.adjacency[a] if n != b]
        self.adjacency[b] = [(n, d) for n, d in self.adjacency[b] if n != a]
        for node in (a, b):
            if not self.adjacency[node]:
                del self.adjacency[node]
        return a, b

    # ---------------- queries ----------------
    def has_road(self, loc1, loc2):
        return any(n == loc2 for n, _ in self.adjacency.get(loc1, []))

    def road_distance(self, loc1, loc2):
        """Length of the direct road between two locations, or None if there is none."""
        for neighbour, d in self.adjacency.get(loc1, []):
            if neighbour == loc2:
                return d
        return None

    def has_location(self, name):
        return name in self.adjacency

    def locations(self):
        return sorted(self.adjacency)

    def resolve(self, name):
        """Case-insensitive lookup. Returns the stored spelling, or None."""
        wanted = str(name).strip().casefold()
        for known in self.adjacency:
            if known.casefold() == wanted:
                return known
        return None

    def roads(self):
        """Each road once, as (loc1, loc2, distance), in a stable order."""
        seen, result = set(), []
        for loc1 in sorted(self.adjacency):
            for loc2, d in sorted(self.adjacency[loc1]):
                key = frozenset((loc1, loc2))
                if key not in seen:
                    seen.add(key)
                    result.append((loc1, loc2, d))
        return result

    # ---------------- Dijkstra ----------------
    def dijkstra(self, start, end):
        """Shortest path using a min-heap, O((V + E) log V).
        Returns (path_list, total_distance), or (None, inf) if unreachable."""
        if start not in self.adjacency or end not in self.adjacency:
            return None, INF
        dist = {node: INF for node in self.adjacency}
        prev = {node: None for node in self.adjacency}
        dist[start] = 0
        heap = MinHeap()
        heap.push((0, start))
        settled = set()
        while heap:
            d, u = heap.pop()
            if u in settled:
                continue                                 # stale entry
            settled.add(u)
            if u == end:
                break
            for v, w in self.adjacency[u]:
                nd = d + w
                if nd < dist[v]:
                    dist[v] = nd
                    prev[v] = u
                    heap.push((nd, v))
        if dist[end] == INF:
            return None, INF
        path, node = [], end
        while node is not None:
            path.append(node)
            node = prev[node]
        path.reverse()
        return path, round(dist[end], 2)
