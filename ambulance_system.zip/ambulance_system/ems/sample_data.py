"""
Demo data, so the system can be tried immediately.

    "city"   36 locations (Bengaluru localities and hospitals), 10 ambulances.  The default.
    "small"  5 locations and 3 ambulances: a tiny map that is easy to follow by hand.

Distances are approximate road kilometres, chosen to be realistic rather than surveyed.
"""

DATASETS = {
    "small": {
        "roads": [
            ("Hospital", "CityPark", 4), ("Hospital", "MallRoad", 2),
            ("MallRoad", "Stadium", 3), ("CityPark", "Stadium", 1),
            ("Stadium", "RailwayStn", 5), ("MallRoad", "Township", 6),
            ("RailwayStn", "Township", 2),
        ],
        "ambulances": [
            ("Ravi Kumar", "KA-01-AB-1234", "Hospital"),
            ("Suresh", "KA-01-CD-5678", "MallRoad"),
            ("Anita", "KA-01-EF-9012", "RailwayStn"),
        ],
    },
    "city": {
        "roads": [
            # North
            ("Yelahanka", "Hebbal", 12), ("Yelahanka", "Airport", 14), ("Yelahanka", "Kothanur", 10),
            ("Airport", "Hennur", 17), ("Airport", "Hebbal", 20),
            ("Hebbal", "Hennur", 9), ("Hebbal", "Shivajinagar", 8), ("Hebbal", "Malleshwaram", 7),
            ("Hebbal", "Yeshwanthpur", 9),
            ("Kothanur", "Hennur", 3), ("Hennur", "Banaswadi", 3),
            # East
            ("Banaswadi", "Indiranagar", 6), ("Banaswadi", "KR Puram", 8),
            ("Indiranagar", "Ulsoor", 3), ("Indiranagar", "Marathahalli", 7),
            ("Indiranagar", "Manipal Hospital", 3), ("Manipal Hospital", "Marathahalli", 5),
            ("Manipal Hospital", "Koramangala", 6),
            ("Marathahalli", "Whitefield", 9), ("Marathahalli", "KR Puram", 7),
            ("Marathahalli", "Bellandur", 4), ("Whitefield", "KR Puram", 11),
            # Centre
            ("Ulsoor", "MG Road", 2), ("MG Road", "Shivajinagar", 3), ("MG Road", "Majestic", 5),
            ("MG Road", "Koramangala", 6), ("MG Road", "Bowring Hospital", 3),
            ("Shivajinagar", "Bowring Hospital", 1), ("Shivajinagar", "Malleshwaram", 5),
            ("Malleshwaram", "Majestic", 4), ("Malleshwaram", "Yeshwanthpur", 4),
            ("Malleshwaram", "Rajajinagar", 4), ("Yeshwanthpur", "Rajajinagar", 3),
            # West
            ("Rajajinagar", "Majestic", 5), ("Rajajinagar", "Vijayanagar", 4),
            ("Vijayanagar", "Majestic", 6), ("Vijayanagar", "Basavanagudi", 8),
            ("Vijayanagar", "Kengeri", 13),
            # South-centre
            ("Majestic", "Victoria Hospital", 3), ("Majestic", "Basavanagudi", 4),
            ("Victoria Hospital", "Basavanagudi", 3), ("Victoria Hospital", "Jayanagar", 4),
            ("Victoria Hospital", "NIMHANS", 5), ("NIMHANS", "Koramangala", 3),
            ("NIMHANS", "Jayanagar", 4), ("Basavanagudi", "Jayanagar", 3),
            ("Basavanagudi", "Banashankari", 4), ("Jayanagar", "Banashankari", 4),
            ("Jayanagar", "JP Nagar", 3), ("Jayanagar", "BTM Layout", 5),
            ("Banashankari", "JP Nagar", 4), ("Banashankari", "Kengeri", 12),
            # South-east
            ("JP Nagar", "BTM Layout", 4), ("JP Nagar", "Bommanahalli", 8),
            ("BTM Layout", "Silk Board", 3), ("BTM Layout", "Koramangala", 4),
            ("Koramangala", "St Johns Hospital", 1), ("Koramangala", "HSR Layout", 4),
            ("Koramangala", "Bellandur", 7), ("HSR Layout", "Silk Board", 3),
            ("HSR Layout", "Bellandur", 5), ("Silk Board", "Bommanahalli", 3),
            ("Silk Board", "Electronic City", 10), ("Bommanahalli", "Electronic City", 8),
            ("Bommanahalli", "Narayana Health", 10), ("Electronic City", "Narayana Health", 6),
        ],
        "ambulances": [
            ("Ravi Kumar", "KA-01-AB-1234", "Victoria Hospital"),
            ("Suresh Babu", "KA-01-CD-5678", "Manipal Hospital"),
            ("Anita Rao", "KA-01-EF-9012", "NIMHANS"),
            ("Imran Khan", "KA-02-GH-3456", "Bowring Hospital"),
            ("Lakshmi Devi", "KA-03-JK-7890", "St Johns Hospital"),
            ("Manoj Gowda", "KA-04-LM-2345", "Narayana Health"),
            ("Prakash Reddy", "KA-05-NP-6789", "Yelahanka"),
            ("Deepa Nair", "KA-05-QR-1122", "Whitefield"),
            ("Harish Shetty", "KA-02-ST-3344", "Kengeri"),
            ("Farida Begum", "KA-01-UV-5566", "Malleshwaram"),
        ],
    },
}
DEFAULT_DATASET = "city"


def load_demo(system, dataset=DEFAULT_DATASET):
    """Add a demo road map and fleet. Returns (roads_added, ambulances_added)."""
    if dataset not in DATASETS:
        raise ValueError(f"Unknown demo dataset {dataset!r}. Choose from: {', '.join(DATASETS)}.")
    data = DATASETS[dataset]
    roads = ambulances = 0
    for a, b, d in data["roads"]:
        if not system.graph.has_road(a, b):
            system.add_road(a, b, d)
            roads += 1
    for driver, vehicle, location in data["ambulances"]:
        try:
            system.register_ambulance(driver, vehicle, location)
            ambulances += 1
        except Exception:                      # already loaded
            pass
    return roads, ambulances
