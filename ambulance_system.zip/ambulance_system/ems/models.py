"""Plain record types used throughout the system."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, IntEnum
from typing import List, Optional


class Severity(IntEnum):
    CRITICAL = 1
    MODERATE = 2
    MINOR = 3

    @property
    def label(self):
        return self.name.capitalize()


class EmergencyStatus(Enum):
    PENDING = "Pending"
    DISPATCHED = "Dispatched"
    COMPLETED = "Completed"
    CANCELLED = "Cancelled"


class AmbulanceStatus(Enum):
    AVAILABLE = "Available"
    ON_DUTY = "On Duty"


@dataclass
class Emergency:
    id: int
    patient_name: str
    age: int
    contact: str
    emergency_type: str
    location: str
    severity: Severity
    status: EmergencyStatus = EmergencyStatus.PENDING
    reported_at: datetime = field(default_factory=datetime.now)


@dataclass
class Ambulance:
    id: int
    driver: str
    vehicle_no: str
    location: str
    status: AmbulanceStatus = AmbulanceStatus.AVAILABLE


@dataclass
class DispatchRecord:
    id: int
    emergency_id: int
    ambulance_id: int
    route: List[str]
    distance: float
    dispatched_at: datetime
    completed_at: Optional[datetime] = None

    @property
    def route_text(self):
        return " -> ".join(self.route)


@dataclass
class DispatchResult:
    record: DispatchRecord
    emergency: Emergency
    ambulance: Ambulance
    skipped: List[Emergency]
