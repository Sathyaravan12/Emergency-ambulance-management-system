"""Interactive console interface. Collects input and prints results; all rules live in system.py."""

import textwrap

from . import __version__
from .errors import EMSError, ValidationError
from .models import AmbulanceStatus, EmergencyStatus, Severity
from .sample_data import DEFAULT_DATASET, load_demo
from .validators import (clean_contact, clean_text, clean_vehicle, parse_age,
                         parse_distance)

WIDTH = 78
CANCEL_WORD = "/cancel"


class _Cancelled(Exception):
    """Raised when the operator types /cancel in the middle of a form."""


def render_table(headers, rows):
    """Plain-text table with aligned columns."""
    rows = [[str(c) for c in r] for r in rows]
    widths = [max([len(h)] + [len(r[i]) for r in rows]) for i, h in enumerate(headers)]
    line = "  ".join("-" * w for w in widths)
    out = ["  ".join(h.ljust(w) for h, w in zip(headers, widths)), line]
    out += ["  ".join(c.ljust(w) for c, w in zip(r, widths)) for r in rows]
    return "\n".join(out)


def _fmt_time(moment):
    return moment.strftime("%d-%b %H:%M") if moment else "-"


class ConsoleApp:
    def __init__(self, system, input_fn=input, output_fn=print, demo_dataset=DEFAULT_DATASET):
        self.system = system
        self.demo_dataset = demo_dataset
        self._in = input_fn
        self._out = output_fn

    # ---------------------------------------------------------------- I/O
    def say(self, text=""):
        self._out(text)

    def heading(self, title):
        self.say()
        self.say("=" * WIDTH)
        self.say(f" {title}")
        self.say("=" * WIDTH)

    def ask(self, prompt, parse=lambda v: v):
        """Prompt until parse() accepts the answer. Type /cancel to abort the form."""
        while True:
            raw = self._in(f"  {prompt}: ").strip()
            if raw.lower() == CANCEL_WORD:
                raise _Cancelled
            try:
                return parse(raw)
            except EMSError as exc:
                self.say(f"  ! {exc}")

    def confirm(self, prompt):
        while True:
            answer = self._in(f"  {prompt} [y/n]: ").strip().lower()
            if answer in ("y", "yes"):
                return True
            if answer in ("n", "no", CANCEL_WORD):
                return False

    def table(self, headers, rows, empty="Nothing to show."):
        self.say(render_table(headers, rows) if rows else f"  {empty}")

    def ask_int(self, label):
        def parse(value):
            try:
                return int(value.lstrip("#"))
            except ValueError:
                raise ValidationError(f"{label} must be a whole number.") from None
        return self.ask(label, parse)

    def ask_location(self, label):
        known = ", ".join(self.system.graph.locations())
        if known:
            self.say(textwrap.fill(f"Known locations: {known}", width=WIDTH - 2,
                                   initial_indent="  ", subsequent_indent="    "))
        return self.ask(label, self.system.require_location)

    def ask_severity(self):
        def parse(value):
            if value not in ("1", "2", "3"):
                raise ValidationError("Enter 1 (critical), 2 (moderate) or 3 (minor).")
            return Severity(int(value))
        return self.ask("Severity  1=Critical  2=Moderate  3=Minor", parse)

    # ---------------------------------------------------------------- menus
    def menu(self, title, options):
        """Show a numbered menu until the operator chooses 0 (back)."""
        while True:
            self.heading(title)
            for number, (label, _) in enumerate(options, 1):
                self.say(f"  {number}. {label}")
            self.say("  0. Back" if title != "MAIN MENU" else "  0. Exit")
            choice = self._in("\n  Choose an option: ").strip()
            if choice == "0":
                return
            if not choice.isdigit() or not 1 <= int(choice) <= len(options):
                self.say("  ! Please enter one of the numbers shown.")
                continue
            try:
                options[int(choice) - 1][1]()
            except _Cancelled:
                self.say("  Cancelled. Nothing was saved.")
            except EMSError as exc:
                self.say(f"  ! {exc}")

    def run(self):
        self.say("=" * WIDTH)
        self.say(f" EMERGENCY AMBULANCE MANAGEMENT SYSTEM  v{__version__}")
        self.say(" Type /cancel at any prompt to abandon the current form.")
        self.say("=" * WIDTH)
        try:
            self.menu("MAIN MENU", [
                ("Emergency management", self.emergency_menu),
                ("Ambulance management", self.ambulance_menu),
                ("Road network", self.road_menu),
                ("Dispatch and routes", self.dispatch_menu),
                ("Reports", self.report_menu),
                ("Load demo road map and fleet", self.load_demo_data),
            ])
        except (EOFError, KeyboardInterrupt):
            self.say()
        self.say("\n  Goodbye.")

    def emergency_menu(self):
        self.menu("EMERGENCY MANAGEMENT", [
            ("Register a new emergency", self.register_emergency),
            ("View intake queue (not yet triaged)", self.show_intake),
            ("Triage: move intake queue into the priority queue", self.triage),
            ("View priority queue (pending, most critical first)", self.show_priority),
            ("Search emergency records", self.search_emergencies),
            ("View all records sorted by priority", self.show_all_by_priority),
            ("Cancel a pending emergency", self.cancel_emergency),
        ])

    def ambulance_menu(self):
        self.menu("AMBULANCE MANAGEMENT", [
            ("Register an ambulance", self.register_ambulance),
            ("View fleet (available first)", self.show_fleet),
            ("Remove an ambulance", self.remove_ambulance),
            ("Mark an ambulance available", self.mark_available),
        ])

    def road_menu(self):
        self.menu("ROAD NETWORK", [
            ("Add a road", self.add_road),
            ("Remove a road", self.remove_road),
            ("View roads", self.show_roads),
            ("View adjacency list", self.show_adjacency),
        ])

    def dispatch_menu(self):
        self.menu("DISPATCH AND ROUTES", [
            ("Dispatch next (highest priority)", self.dispatch_next),
            ("Complete a dispatch", self.complete_dispatch),
            ("Find shortest route between two locations", self.shortest_route),
        ])

    def report_menu(self):
        self.menu("REPORTS", [
            ("Dashboard", self.dashboard),
            ("Dispatch history", self.show_history),
        ])

    # ---------------------------------------------------------------- emergencies
    def register_emergency(self):
        self.heading("REGISTER EMERGENCY")
        name = self.ask("Patient name", lambda v: clean_text(v, "Patient name"))
        age = self.ask("Patient age", parse_age)
        contact = self.ask("Contact number", clean_contact)
        kind = self.ask("Emergency type (e.g. accident, cardiac)", lambda v: clean_text(v, "Emergency type"))
        location = self.ask_location("Location")
        severity = self.ask_severity()
        e = self.system.register_emergency(name, age, contact, kind, location, severity)
        self.say(f"\n  Emergency #{e.id} registered for {e.patient_name} ({e.severity.label}) "
                 f"and added to the intake queue.")

    def show_intake(self):
        self.heading("INTAKE QUEUE (first in, first out)")
        self._emergency_table(self.system.intake_snapshot(), "The intake queue is empty.")

    def triage(self):
        moved = self.system.triage()
        self.say(f"  {moved} request(s) moved into the priority queue." if moved
                 else "  The intake queue is empty.")

    def show_priority(self):
        self.heading("PRIORITY QUEUE (most critical first)")
        self._emergency_table(self.system.priority_snapshot(), "No pending emergencies.")
        waiting = len(self.system.intake_queue)
        if waiting:
            self.say(f"\n  Note: {waiting} request(s) are still in the intake queue. "
                     f"Triage them to include them here.")

    def search_emergencies(self):
        text = self.ask("Patient name (or part of it) or #id", lambda v: clean_text(v, "Search text"))
        if text.lstrip("#").isdigit():
            matches = [self.system.find_emergency(int(text.lstrip("#")))]
        else:
            matches = self.system.search_emergencies(text)
        self.heading("SEARCH RESULTS")
        self._emergency_table(matches, "No matching emergency records.", with_status=True)

    def show_all_by_priority(self):
        self.heading("ALL EMERGENCY RECORDS (sorted by priority, selection sort)")
        self._emergency_table(self.system.emergencies_by_priority(), "No emergencies recorded yet.",
                              with_status=True)

    def cancel_emergency(self):
        self.show_priority()
        eid = self.ask_int("Emergency id to cancel")
        e = self.system.find_emergency(eid)
        if self.confirm(f"Cancel emergency #{e.id} for {e.patient_name}?"):
            self.system.cancel_emergency(eid)
            self.say(f"  Emergency #{eid} cancelled.")

    def _emergency_table(self, items, empty, with_status=False):
        headers = ["ID", "Patient", "Age", "Type", "Location", "Severity"]
        if with_status:
            headers.append("Status")
        headers.append("Reported")
        rows = []
        for e in items:
            row = [f"#{e.id}", e.patient_name, e.age, e.emergency_type, e.location, e.severity.label]
            if with_status:
                row.append(e.status.value)
            row.append(_fmt_time(e.reported_at))
            rows.append(row)
        self.table(headers, rows, empty)

    # ---------------------------------------------------------------- ambulances
    def register_ambulance(self):
        self.heading("REGISTER AMBULANCE")
        driver = self.ask("Driver name", lambda v: clean_text(v, "Driver name"))
        vehicle = self.ask("Vehicle number (e.g. KA-01-AB-1234)", clean_vehicle)
        location = self.ask_location("Current location")
        a = self.system.register_ambulance(driver, vehicle, location)
        self.say(f"\n  Ambulance #{a.id} ({a.vehicle_no}) added to the fleet at {a.location}.")

    def show_fleet(self):
        self.heading("FLEET (available first)")
        rows = [[f"#{a.id}", a.driver, a.vehicle_no, a.location, a.status.value]
                for a in self.system.fleet_by_availability()]
        self.table(["ID", "Driver", "Vehicle", "Location", "Status"], rows, "No ambulances registered.")

    def remove_ambulance(self):
        self.show_fleet()
        aid = self.ask_int("Ambulance id to remove")
        a = self.system.find_ambulance(aid)
        if self.confirm(f"Remove ambulance {a.vehicle_no}?"):
            self.system.remove_ambulance(aid)
            self.say(f"  Ambulance {a.vehicle_no} removed.")

    def mark_available(self):
        self.show_fleet()
        a = self.system.mark_available(self.ask_int("Ambulance id"))
        self.say(f"  Ambulance {a.vehicle_no} is now available.")

    # ---------------------------------------------------------------- roads
    def add_road(self):
        self.heading("ADD ROAD")
        if self.system.graph.locations():
            self.say(textwrap.fill(f"Existing locations: {', '.join(self.system.graph.locations())}",
                                   width=WIDTH - 2, initial_indent="  ", subsequent_indent="    "))
        a = self.ask("Location A", lambda v: clean_text(v, "Location A", 40))
        b = self.ask("Location B", lambda v: clean_text(v, "Location B", 40))
        km = self.ask("Distance in km", parse_distance)
        loc1, loc2 = self.system.add_road(a, b, km)
        self.say(f"  Road added: {loc1} <-> {loc2} ({km} km).")

    def remove_road(self):
        self.show_roads()
        a = self.ask("Location A", lambda v: clean_text(v, "Location A", 40))
        b = self.ask("Location B", lambda v: clean_text(v, "Location B", 40))
        loc1, loc2 = self.system.remove_road(a, b)
        self.say(f"  Road {loc1} <-> {loc2} removed.")

    def show_roads(self):
        self.heading("ROADS")
        rows = [[a, b, f"{d} km"] for a, b, d in self.system.graph.roads()]
        self.table(["From", "To", "Distance"], rows, "No roads yet. Add one to start the map.")

    def show_adjacency(self):
        self.heading("ADJACENCY LIST")
        graph = self.system.graph
        if not graph.adjacency:
            self.say("  The road network is empty.")
        for loc in graph.locations():
            neighbours = ", ".join(f"{n} ({d} km)" for n, d in sorted(graph.adjacency[loc]))
            self.say(f"  {loc:<14} -> {neighbours}")

    # ---------------------------------------------------------------- dispatch
    def dispatch_next(self):
        result = self.system.dispatch_next()
        e, a, r = result.emergency, result.ambulance, result.record
        self.heading("AMBULANCE DISPATCHED")
        self.say(f"  Emergency : #{e.id} {e.patient_name}, {e.emergency_type} ({e.severity.label})")
        self.say(f"  Ambulance : #{a.id} {a.vehicle_no}, driver {a.driver}")
        self.say(f"  Route     : {r.route_text}")
        self.say(f"  Distance  : {r.distance} km")
        self.say(f"  Status    : ambulance is now On Duty at {e.location}")
        if result.skipped:
            ids = ", ".join(f"#{s.id}" for s in result.skipped)
            self.say(f"\n  Warning: higher-priority emergencies {ids} could not be reached by any "
                     f"free ambulance and remain pending.")

    def complete_dispatch(self):
        self.show_history()
        eid = self.ask_int("Emergency id to complete")
        self.system.complete_dispatch(eid)
        self.say(f"  Emergency #{eid} completed. The ambulance is available again.")

    def shortest_route(self):
        self.heading("SHORTEST ROUTE (Dijkstra)")
        start = self.ask_location("From")
        end = self.ask_location("To")
        path, distance = self.system.shortest_route(start, end)
        self.say(f"\n  Route    : {' -> '.join(path)}")
        self.say(f"  Distance : {distance} km")

    # ---------------------------------------------------------------- reports
    def dashboard(self):
        s = self.system.stats()
        self.heading("DASHBOARD")
        self.say(f"  Locations / roads        : {s['locations']} / {s['roads']}")
        self.say(f"  Ambulances (available)   : {s['ambulances']} ({s['available']})")
        self.say(f"  Waiting in intake queue  : {s['intake']}")
        self.say(f"  Pending emergencies      : {s['pending']}")
        self.say(f"  Dispatches in progress   : {s['active']}")
        self.say(f"  Completed emergencies    : {s['completed']}")

    def show_history(self):
        self.heading("DISPATCH HISTORY")
        rows = []
        for d in reversed(self.system.dispatches):
            e = self.system.find_emergency(d.emergency_id)
            a = self.system.find_ambulance(d.ambulance_id)
            state = "Completed" if d.completed_at else "In progress"
            rows.append([f"#{e.id}", e.patient_name, a.vehicle_no, d.route_text,
                         f"{d.distance} km", _fmt_time(d.dispatched_at), state])
        self.table(["Emerg.", "Patient", "Vehicle", "Route", "Distance", "Dispatched", "Status"],
                   rows, "No dispatches yet.")

    def load_demo_data(self):
        roads, ambulances = load_demo(self.system, self.demo_dataset)
        if roads or ambulances:
            self.say(f"  Loaded {roads} road(s) and {ambulances} ambulance(s).")
        else:
            self.say("  The demo data is already loaded.")
