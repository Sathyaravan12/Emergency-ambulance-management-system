"""Emergency Ambulance Management System (console edition)."""

__version__ = "1.0.0"
