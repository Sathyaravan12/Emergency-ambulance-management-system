import os
import re
import tempfile
import unittest

from webapp import create_app
from webapp.helpers import LoginThrottle


class WebTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data_file = os.path.join(self.tmp.name, "data.json")
        self.boot()

    def boot(self):
        """(Re)start the application against the same data file."""
        self.app = create_app({"TESTING": True, "SECRET_KEY": "test", "DATA_FILE": self.data_file,
                               "DEMO_DATASET": "small"})
        self.client = self.app.test_client()
        self.store = self.app.extensions["store"]

    def tearDown(self):
        self.tmp.cleanup()

    def token(self, page="/login"):
        html = self.client.get(page).get_data(as_text=True)
        return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)

    def post(self, path, data=None, page="/dashboard", follow=True):
        data = dict(data or {}, csrf_token=self.token(page))
        return self.client.post(path, data=data, follow_redirects=follow)

    def text(self, path):
        return self.client.get(path).get_data(as_text=True)

    def login(self):
        r = self.post("/login", {"username": "admin", "password": "admin123"}, page="/login")
        self.assertIn("Console Overview", r.get_data(as_text=True))

    def report(self, name="Asha", severity="2", location="Stadium", **kw):
        data = {"patient_name": name, "age": kw.get("age", "30"), "contact": kw.get("contact", "9876543210"),
                "emergency_type": kw.get("kind", "Road accident"), "location": location, "severity": severity}
        return self.post("/emergencies", data, page="/emergencies")


class AuthTests(WebTestCase):
    def test_pages_require_login(self):
        for path in ["/dashboard", "/emergencies", "/records", "/ambulances", "/roads", "/history"]:
            self.assertEqual(self.client.get(path).status_code, 302, path)

    def test_login_logout_and_csrf(self):
        self.login()
        self.assertEqual(self.client.get("/logout").status_code, 405)
        self.assertIn("Sign in to the console", self.post("/logout").get_data(as_text=True))
        self.assertEqual(self.client.post("/login", data={"username": "admin", "password": "admin123"}).status_code, 400)

    def test_registration_rules(self):
        base = {"full_name": "Op Erator", "username": "operator", "password": "secret1", "confirm_password": "secret1"}
        cases = [({"username": "ab"}, "Username must be"), ({"password": "123", "confirm_password": "123"}, "at least 6"),
                 ({"confirm_password": "other1"}, "do not match"), ({"full_name": " "}, "Full name is required")]
        for change, message in cases:
            r = self.post("/register", dict(base, **change), page="/register")
            self.assertIn(message, r.get_data(as_text=True))
        self.assertIn("Account created", self.post("/register", base, page="/register").get_data(as_text=True))
        self.assertIn("already taken", self.post("/register", dict(base, username="OPERATOR"), page="/register").get_data(as_text=True))
        r = self.post("/login", {"username": "operator", "password": "secret1"}, page="/login")
        self.assertIn("Console Overview", r.get_data(as_text=True))

    def test_login_throttle(self):
        for _ in range(5):
            self.post("/login", {"username": "admin", "password": "wrong"}, page="/login")
        r = self.post("/login", {"username": "admin", "password": "admin123"}, page="/login")
        self.assertIn("Too many failed attempts", r.get_data(as_text=True))

    def test_throttle_window_expires(self):
        now = [0.0]
        t = LoginThrottle(max_failures=2, window_seconds=10, clock=lambda: now[0])
        t.record_failure("k"); t.record_failure("k")
        self.assertTrue(t.blocked("k"))
        now[0] = 11
        self.assertFalse(t.blocked("k"))


class WorkflowTests(WebTestCase):
    def setUp(self):
        super().setUp()
        self.login()

    def test_all_pages_render(self):
        for path in ["/dashboard", "/emergencies", "/records", "/ambulances", "/roads", "/history",
                     "/roads?from=Hospital&to=RailwayStn"]:
            self.assertEqual(self.client.get(path).status_code, 200, path)

    def test_register_triage_dispatch_complete(self):
        self.report("Minor Mike", "3")
        self.report("Critical Cara", "1", location="Township")
        self.assertIn("Minor Mike", self.text("/emergencies"))                  # both waiting in intake
        self.assertIn("2 request(s) moved", self.post("/emergencies/triage", page="/emergencies").get_data(as_text=True))
        r = self.post("/dispatch", page="/emergencies")
        self.assertIn("dispatched to Critical Cara", r.get_data(as_text=True))
        self.assertIn("RailwayStn", r.get_data(as_text=True))
        r = self.post("/emergencies/2/complete", page="/history")
        self.assertIn("completed", r.get_data(as_text=True))
        with self.store.read() as s:
            self.assertEqual(s.stats()["completed"], 1)
            self.assertEqual(s.stats()["available"], 3)

    def test_patient_details_are_stored(self):
        self.report("Detail Dev", "2", age="47", contact="+91 98765-43210", kind="Cardiac arrest")
        with self.store.read() as s:
            e = s.find_emergency(1)
            self.assertEqual((e.age, e.contact, e.emergency_type), (47, "+919876543210", "Cardiac arrest"))

    def test_validation_errors_never_crash(self):
        bad = [dict(age="abc"), dict(age="-1"), dict(age="500"), dict(contact="12"), dict(severity="9"),
               dict(severity="x"), dict(location="Atlantis"), dict(name="   "), dict(kind="")]
        for change in bad:
            args = dict(name="Asha", severity="2", location="Stadium")
            args.update(change)
            r = self.report(args.pop("name"), **args)
            self.assertEqual(r.status_code, 200, change)
        with self.store.read() as s:
            self.assertEqual(len(s.emergencies), 0)

    def test_unreachable_emergency_does_not_block_queue(self):
        self.post("/roads", {"loc1": "Island", "loc2": "Beach", "distance": "2"}, page="/roads")
        self.report("Stranded", "1", location="Beach")
        self.report("Reachable", "3")
        body = self.post("/dispatch", page="/emergencies").get_data(as_text=True)
        self.assertIn("dispatched to Reachable", body)
        self.assertIn("could not be reached", body)

    def test_dispatch_with_nothing_pending_and_cancel(self):
        self.assertIn("no pending emergencies", self.post("/dispatch", page="/emergencies").get_data(as_text=True))
        self.report("Cancel Me")
        self.post("/emergencies/1/cancel", page="/emergencies")
        self.assertIn("Cancelled", self.text("/records"))
        self.assertIn("Only pending", self.post("/emergencies/1/cancel", page="/emergencies").get_data(as_text=True))

    def test_records_sorted_and_searchable(self):
        self.report("Minor Mike", "3")
        self.report("Critical Cara", "1")
        page = self.text("/records")
        self.assertLess(page.index("Critical Cara"), page.index("Minor Mike"))          # priority order
        self.assertNotIn("Minor Mike", self.text("/records?q=cara"))
        self.assertIn("Minor Mike", self.text("/records?q=%231"))
        self.assertIn("No matching", self.text("/records?q=%23999"))
        self.assertIn("No matching", self.text("/records?q=zzz"))

    def test_fleet_management(self):
        data = {"driver": "New Driver", "vehicle_no": "ka-09-zz-0001", "location": "Hospital"}
        self.post("/ambulances", data, page="/ambulances")
        self.assertIn("KA-09-ZZ-0001", self.text("/ambulances"))
        self.assertIn("already registered", self.post("/ambulances", data, page="/ambulances").get_data(as_text=True))
        self.assertIn("Unknown location", self.post("/ambulances", dict(data, vehicle_no="KA-10-AA-0002", location="Mars"),
                                                    page="/ambulances").get_data(as_text=True))
        self.assertIn("removed", self.post("/ambulances/4/delete", page="/ambulances").get_data(as_text=True))
        self.assertEqual(self.client.post("/ambulances/99/delete", data={"csrf_token": self.token("/ambulances")}).status_code, 404)

    def test_cannot_remove_ambulance_on_duty(self):
        self.report("Cara", "1")
        self.post("/dispatch", page="/emergencies")
        with self.store.read() as s:
            busy = s.dispatches[0].ambulance_id
        self.assertIn("cannot be removed", self.post(f"/ambulances/{busy}/delete", page="/ambulances").get_data(as_text=True))

    def test_roads_and_route_finder(self):
        before = len(self.store.system.graph.roads())
        for dist in ("-5", "0", "nan", "inf", "abc", "99999"):
            self.assertEqual(self.post("/roads", {"loc1": "A", "loc2": "B", "distance": dist}, page="/roads").status_code, 200)
        self.post("/roads", {"loc1": "A", "loc2": "a", "distance": "3"}, page="/roads")
        self.post("/roads", {"loc1": "hospital", "loc2": "citypark", "distance": "3"}, page="/roads")
        self.assertEqual(len(self.store.system.graph.roads()), before)
        page = self.text("/roads?from=Hospital&to=RailwayStn")
        self.assertIn("10.0 km", page)
        self.assertIn("graph-edge-hot", page)
        self.assertIn("Road Hospital - CityPark removed", self.post(
            "/roads/delete", {"loc1": "Hospital", "loc2": "CityPark"}, page="/roads").get_data(as_text=True))

    def test_user_text_is_escaped_and_not_placed_in_javascript(self):
        evil = "<script>alert(1)</script>"
        self.report(evil)
        self.report("O'Brien');alert(2);//")
        for page in ("/emergencies", "/records", "/dashboard"):
            html = self.text(page)
            self.assertNotIn(evil, html)
            self.assertNotIn("onsubmit", html)
        self.assertIn("&lt;script&gt;", self.text("/emergencies"))

    def test_error_pages(self):
        r = self.client.get("/missing")
        self.assertEqual(r.status_code, 404)
        self.assertIn("does not exist", r.get_data(as_text=True))


class PersistenceTests(WebTestCase):
    def test_data_survives_a_restart(self):
        self.login()
        self.report("Survivor", "1")
        self.post("/ambulances", {"driver": "Kept", "vehicle_no": "KA-05-KK-0005", "location": "Hospital"}, page="/ambulances")
        self.boot()                                           # simulated restart
        self.login()
        self.assertIn("Survivor", self.text("/emergencies"))
        self.assertIn("KA-05-KK-0005", self.text("/ambulances"))
        self.report("After restart", "2")
        with self.store.read() as s:
            self.assertEqual([e.id for e in s.emergencies], [1, 2])

    def test_registered_accounts_survive_a_restart(self):
        self.post("/register", {"full_name": "New Op", "username": "newop", "password": "secret1",
                                "confirm_password": "secret1"}, page="/register")
        self.boot()
        r = self.post("/login", {"username": "newop", "password": "secret1"}, page="/login")
        self.assertIn("Console Overview", r.get_data(as_text=True))

    def test_seed_is_skipped_when_disabled(self):
        app = create_app({"TESTING": True, "SECRET_KEY": "x", "SEED_DEMO_DATA": False,
                          "DATA_FILE": os.path.join(self.tmp.name, "empty.json")})
        with app.extensions["store"].read() as s:
            self.assertEqual(len(s.graph.roads()), 0)
        self.assertEqual(app.extensions["store"].users, {})


if __name__ == "__main__":
    unittest.main()
