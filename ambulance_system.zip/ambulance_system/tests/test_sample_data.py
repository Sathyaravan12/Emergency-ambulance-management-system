import os
import re
import tempfile
import unittest

from ems.errors import EMSError
from ems.sample_data import DATASETS, load_demo
from ems.system import EmergencyAmbulanceSystem
from ems.validators import clean_vehicle
from webapp import create_app
from webapp.helpers import _label_box, layout_graph


def city():
    s = EmergencyAmbulanceSystem()
    load_demo(s)                                         # default dataset
    return s


class CityDatasetTests(unittest.TestCase):
    def test_has_at_least_thirty_locations_and_a_full_fleet(self):
        s = city()
        self.assertGreaterEqual(len(s.graph.locations()), 30)
        self.assertEqual(len(s.graph.locations()), 36)
        self.assertEqual(len(list(s.ambulances)), 10)

    def test_every_location_is_reachable_from_every_other(self):
        s = city()
        names = s.graph.locations()
        for target in names:
            self.assertIsNotNone(s.graph.dijkstra(names[0], target)[0], f"{target} is cut off")

    def test_data_is_clean(self):
        data = DATASETS["city"]
        vehicles = [v for _, v, _ in data["ambulances"]]
        self.assertEqual(len(vehicles), len(set(vehicles)))
        for v in vehicles:
            self.assertEqual(clean_vehicle(v), v)
        known = set(city().graph.locations())
        self.assertTrue(all(loc in known for _, _, loc in data["ambulances"]))
        self.assertTrue(all(d > 0 for _, _, d in data["roads"]))
        keys = [frozenset((a, b)) for a, b, _ in data["roads"]]
        self.assertEqual(len(keys), len(set(keys)), "duplicate road in the dataset")

    def test_loading_twice_changes_nothing(self):
        s = city()
        self.assertEqual(load_demo(s), (0, 0))

    def test_unknown_dataset(self):
        with self.assertRaises(ValueError):
            load_demo(EmergencyAmbulanceSystem(), "mars")

    def test_dispatch_across_the_city(self):
        s = city()
        s.register_emergency("Far Away", 30, "9876543210", "Cardiac arrest", "whitefield", 1)
        result = s.dispatch_next()
        self.assertEqual(result.ambulance.vehicle_no, "KA-05-QR-1122")      # parked at Whitefield
        self.assertEqual(result.record.distance, 0)
        s.register_emergency("Second", 30, "9876543210", "Fall", "Whitefield", 1)
        second = s.dispatch_next()                                         # nearest free unit is elsewhere
        self.assertGreater(second.record.distance, 0)
        self.assertEqual(second.record.route[-1], "Whitefield")


class CityDiagramTests(unittest.TestCase):
    def test_compact_layout_has_no_overlapping_labels_and_stays_in_bounds(self):
        diagram = layout_graph(city().graph)
        self.assertTrue(diagram["compact"])
        self.assertEqual(len(diagram["nodes"]), 36)
        boxes = [(n["name"], _label_box(n["name"], n["x"], n["y"])) for n in diagram["nodes"]]
        for _, (x0, y0, x1, y1) in boxes:
            self.assertTrue(0 <= x0 and x1 <= diagram["size"] and 0 <= y0 and y1 <= diagram["size"])
        for i, (a, (ax0, ay0, ax1, ay1)) in enumerate(boxes):
            for b, (bx0, by0, bx1, by1) in boxes[i + 1:]:
                overlap = min(ax1, bx1) > max(ax0, bx0) and min(ay1, by1) > max(ay0, by0)
                self.assertFalse(overlap, f"labels of {a} and {b} overlap")

    def test_layout_is_deterministic(self):
        a, b = layout_graph(city().graph), layout_graph(city().graph)
        self.assertEqual(a["nodes"], b["nodes"])

    def test_small_map_keeps_the_circle_layout(self):
        s = EmergencyAmbulanceSystem()
        load_demo(s, "small")
        self.assertFalse(layout_graph(s.graph)["compact"])

    def test_route_is_highlighted(self):
        diagram = layout_graph(city().graph, ["Whitefield", "Marathahalli"])
        self.assertEqual(sum(e["hot"] for e in diagram["edges"]), 1)
        self.assertEqual(sum(n["hot"] for n in diagram["nodes"]), 2)


class CityWebTests(unittest.TestCase):
    def test_web_app_seeds_the_city_by_default(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app({"TESTING": True, "SECRET_KEY": "k", "DATA_FILE": os.path.join(tmp, "d.json")})
            client = app.test_client()
            html = client.get("/login").get_data(as_text=True)
            token = re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)
            client.post("/login", data={"username": "admin", "password": "admin123", "csrf_token": token})
            page = client.get("/roads?from=Whitefield&to=Kengeri").get_data(as_text=True)
            self.assertEqual(page.count('class="graph-dot'), 36)
            self.assertIn("graph-compact", page)
            self.assertIn("graph-edge-hot", page)
            self.assertIn("Banashankari → Kengeri", page)                    # per-leg breakdown
            self.assertIn("<option value=\"Yelahanka\"", client.get("/emergencies").get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
