import unittest

from ems.errors import NotFoundError, OperationError, ValidationError
from ems.models import AmbulanceStatus, EmergencyStatus
from ems.sample_data import load_demo
from ems.system import EmergencyAmbulanceSystem


def make_system():
    s = EmergencyAmbulanceSystem()
    load_demo(s, "small")
    return s


def report(s, name="Asha", location="Stadium", severity=2, **kw):
    return s.register_emergency(name, kw.get("age", 30), kw.get("contact", "9876543210"),
                                kw.get("kind", "Accident"), location, severity)


class RegistrationTests(unittest.TestCase):
    def test_register_goes_to_intake_queue_then_triage(self):
        s = make_system()
        e = report(s, location="stadium")
        self.assertEqual(e.location, "Stadium")                  # case-insensitive match
        self.assertEqual(len(s.intake_queue), 1)
        self.assertEqual(s.triage(), 1)
        self.assertEqual(len(s.intake_queue), 0)
        self.assertEqual(s.priority_snapshot(), [e])

    def test_validation(self):
        s = make_system()
        bad_inputs = [
            dict(name="  "), dict(age=-1), dict(age="abc"), dict(age=200), dict(contact="12ab"),
            dict(kind=""), dict(location="Atlantis"), dict(severity=9), dict(severity="x"),
        ]
        for bad in bad_inputs:
            args = dict(name="Asha", age=30, contact="9876543210", kind="Accident",
                        location="Stadium", severity=2)
            args.update(bad)
            with self.assertRaises(ValidationError, msg=str(bad)):
                s.register_emergency(args["name"], args["age"], args["contact"], args["kind"],
                                     args["location"], args["severity"])
        self.assertEqual(len(s.emergencies), 0)

    def test_search_and_sorted_records(self):
        s = make_system()
        report(s, "Minor Mike", severity=3)
        report(s, "Critical Cara", severity=1)
        self.assertEqual(s.find_emergency(2).patient_name, "Critical Cara")
        self.assertEqual([e.patient_name for e in s.search_emergencies("mike")], ["Minor Mike"])
        self.assertEqual([e.id for e in s.emergencies_by_priority()], [2, 1])
        with self.assertRaises(NotFoundError):
            s.find_emergency(99)

    def test_cancel(self):
        s = make_system()
        a, b = report(s, "A"), report(s, "B")
        s.triage()
        c = report(s, "C")                                       # still in the intake queue
        s.cancel_emergency(a.id)
        s.cancel_emergency(c.id)
        self.assertEqual([e.id for e in s.priority_snapshot()], [b.id])
        self.assertEqual(len(s.intake_queue), 0)
        self.assertIs(a.status, EmergencyStatus.CANCELLED)
        with self.assertRaises(OperationError):
            s.cancel_emergency(a.id)


class DispatchTests(unittest.TestCase):
    def test_most_critical_first_and_nearest_ambulance(self):
        s = make_system()
        report(s, "Minor Mike", "Stadium", 3)
        report(s, "Critical Cara", "Township", 1)
        result = s.dispatch_next()
        self.assertEqual(result.emergency.patient_name, "Critical Cara")
        self.assertEqual(result.ambulance.vehicle_no, "KA-01-EF-9012")   # at RailwayStn, 2 km away
        self.assertEqual(result.record.distance, 2)
        self.assertIs(result.ambulance.status, AmbulanceStatus.ON_DUTY)
        self.assertEqual(result.ambulance.location, "Township")
        self.assertEqual([e.patient_name for e in s.priority_snapshot()], ["Minor Mike"])

    def test_same_severity_is_first_come_first_served(self):
        s = make_system()
        report(s, "First", "Stadium", 2)
        report(s, "Second", "Stadium", 2)
        self.assertEqual(s.dispatch_next().emergency.patient_name, "First")

    def test_no_ambulance_keeps_request_pending(self):
        s = EmergencyAmbulanceSystem()
        s.add_road("A", "B", 1)
        e = report(s, "Solo", "A", 1)
        with self.assertRaises(OperationError):
            s.dispatch_next()
        self.assertIs(e.status, EmergencyStatus.PENDING)
        self.assertEqual(s.priority_snapshot(), [e])

    def test_unreachable_emergency_does_not_block_others(self):
        s = make_system()
        s.add_road("Island", "Beach", 2)
        stranded = report(s, "Stranded", "Beach", 1)
        reachable = report(s, "Reachable", "Stadium", 3)
        result = s.dispatch_next()
        self.assertEqual(result.emergency.id, reachable.id)
        self.assertEqual([e.id for e in result.skipped], [stranded.id])
        self.assertEqual(s.priority_snapshot(), [stranded])      # still pending, not lost

    def test_nothing_pending(self):
        with self.assertRaises(OperationError):
            make_system().dispatch_next()

    def test_busy_ambulances_are_skipped_until_all_used(self):
        s = make_system()
        for i in range(3):
            report(s, f"P{i}", "Stadium", 2)
            s.dispatch_next()
        report(s, "Extra", "Stadium", 2)
        with self.assertRaises(OperationError):
            s.dispatch_next()                                    # fleet of 3 is exhausted

    def test_complete_dispatch_frees_ambulance(self):
        s = make_system()
        e = report(s, severity=1)
        amb = s.dispatch_next().ambulance
        s.complete_dispatch(e.id)
        self.assertIs(amb.status, AmbulanceStatus.AVAILABLE)
        self.assertIs(e.status, EmergencyStatus.COMPLETED)
        self.assertIsNotNone(s.dispatches[0].completed_at)
        with self.assertRaises(OperationError):
            s.complete_dispatch(e.id)                            # cannot complete twice


class FleetAndRoadTests(unittest.TestCase):
    def test_register_duplicate_and_unknown_location(self):
        s = make_system()
        with self.assertRaises(ValidationError):
            s.register_ambulance("X", "ka-01-ab-1234", "Hospital")      # duplicate (case-insensitive)
        with self.assertRaises(ValidationError):
            s.register_ambulance("X", "KA-09-ZZ-0001", "Nowhere")
        with self.assertRaises(ValidationError):
            s.register_ambulance("X", "!!", "Hospital")
        self.assertEqual(len(s.ambulances), 3)

    def test_fleet_sorted_available_first(self):
        s = make_system()
        s.find_ambulance(1).status = AmbulanceStatus.ON_DUTY
        self.assertEqual([a.id for a in s.fleet_by_availability()], [2, 3, 1])

    def test_remove_ambulance_rules(self):
        s = make_system()
        report(s, severity=1)
        used = s.dispatch_next().ambulance
        with self.assertRaises(OperationError):
            s.remove_ambulance(used.id)                          # on duty
        s.complete_dispatch(1)
        with self.assertRaises(OperationError):
            s.remove_ambulance(used.id)                          # has history
        spare = next(a for a in s.ambulances if a.id != used.id)
        s.remove_ambulance(spare.id)
        self.assertEqual(len(s.ambulances), 2)

    def test_mark_available_rules(self):
        s = make_system()
        report(s, severity=1)
        amb = s.dispatch_next().ambulance
        with self.assertRaises(OperationError):
            s.mark_available(amb.id)                             # active dispatch must be completed
        idle = next(a for a in s.ambulances if a.id != amb.id)
        with self.assertRaises(OperationError):
            s.mark_available(idle.id)                            # already available

    def test_roads_and_routes(self):
        s = make_system()
        path, dist = s.shortest_route("hospital", "RAILWAYSTN")
        self.assertEqual((path[0], path[-1], dist), ("Hospital", "RailwayStn", 10))
        with self.assertRaises(ValidationError):
            s.add_road("A", "B", "-3")
        with self.assertRaises(ValidationError):
            s.add_road("Hospital", "hospital", 3)
        s.add_road("Island", "Beach", 1)
        with self.assertRaises(NotFoundError):
            s.shortest_route("Hospital", "Island")

    def test_stats(self):
        s = make_system()
        report(s)
        stats = s.stats()
        self.assertEqual((stats["ambulances"], stats["available"], stats["pending"], stats["intake"]),
                         (3, 3, 1, 1))


if __name__ == "__main__":
    unittest.main()
