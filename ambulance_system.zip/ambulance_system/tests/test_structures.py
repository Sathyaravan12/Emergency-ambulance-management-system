import math
import unittest

from ems.algorithms import linear_search, linear_search_all, selection_sort
from ems.graph import Graph
from ems.structures import LinkedList, MinHeap, PriorityQueue, Queue


class LinkedListTests(unittest.TestCase):
    def test_append_prepend_and_traverse(self):
        ll = LinkedList([2, 3])
        ll.prepend(1)
        ll.append(4)
        self.assertEqual(list(ll), [1, 2, 3, 4])
        self.assertEqual(len(ll), 4)

    def test_remove_head_middle_tail(self):
        ll = LinkedList([1, 2, 3, 4])
        self.assertTrue(ll.remove_first(lambda v: v == 1))
        self.assertTrue(ll.remove_first(lambda v: v == 3))
        self.assertTrue(ll.remove_first(lambda v: v == 4))
        self.assertFalse(ll.remove_first(lambda v: v == 99))
        self.assertEqual(list(ll), [2])
        ll.append(5)                         # tail pointer must still be valid
        self.assertEqual(list(ll), [2, 5])

    def test_remove_all(self):
        ll = LinkedList([1, 2, 2, 3, 2])
        self.assertEqual(ll.remove_all(lambda v: v == 2), 3)
        self.assertEqual(list(ll), [1, 3])

    def test_empty_list_errors(self):
        with self.assertRaises(IndexError):
            LinkedList().pop_front()


class QueueTests(unittest.TestCase):
    def test_fifo(self):
        q = Queue([1, 2, 3])
        self.assertEqual([q.dequeue(), q.dequeue(), q.dequeue()], [1, 2, 3])
        self.assertTrue(q.is_empty())
        with self.assertRaises(IndexError):
            q.dequeue()

    def test_remove_if_keeps_order(self):
        q = Queue([1, 2, 3, 4])
        self.assertEqual(q.remove_if(lambda v: v % 2 == 0), 2)
        self.assertEqual(list(q), [1, 3])
        q.enqueue(5)
        self.assertEqual(list(q), [1, 3, 5])


class HeapAndPriorityQueueTests(unittest.TestCase):
    def test_heap_sorted_output(self):
        h = MinHeap()
        for n in [5, 3, 8, 1, 9, 2, 7, 3]:
            h.push(n)
        self.assertEqual([h.pop() for _ in range(len(h))], [1, 2, 3, 3, 5, 7, 8, 9])

    def test_priority_then_arrival(self):
        pq = PriorityQueue()
        for order, sev in [(1, 3), (2, 1), (3, 2), (4, 1)]:
            pq.push(sev, order, f"e{order}")
        self.assertEqual(pq.ordered(), ["e2", "e4", "e3", "e1"])
        self.assertEqual(len(pq), 4)                       # ordered() does not consume
        self.assertEqual(pq.pop(), "e2")

    def test_remove_if_rebuilds_heap(self):
        pq = PriorityQueue()
        for order, sev in [(1, 3), (2, 1), (3, 2)]:
            pq.push(sev, order, order)
        self.assertEqual(pq.remove_if(lambda p: p == 2), 1)
        self.assertEqual(pq.ordered(), [3, 1])


class AlgorithmTests(unittest.TestCase):
    def test_linear_search(self):
        self.assertEqual(linear_search([1, 2, 3], lambda v: v > 1), 2)
        self.assertIsNone(linear_search([1, 2, 3], lambda v: v > 5))
        self.assertEqual(linear_search_all([1, 2, 3, 4], lambda v: v % 2 == 0), [2, 4])

    def test_selection_sort(self):
        data = [5, 2, 9, 1, 5, 6]
        self.assertEqual(selection_sort(data), sorted(data))
        self.assertEqual(data, [5, 2, 9, 1, 5, 6])         # input untouched
        self.assertEqual(selection_sort([]), [])


def sample_graph():
    g = Graph()
    for a, b, d in [("Hospital", "CityPark", 4), ("Hospital", "MallRoad", 2), ("MallRoad", "Stadium", 3),
                    ("CityPark", "Stadium", 1), ("Stadium", "RailwayStn", 5), ("MallRoad", "Township", 6),
                    ("RailwayStn", "Township", 2)]:
        g.add_road(a, b, d)
    return g


class GraphTests(unittest.TestCase):
    def test_shortest_path(self):
        path, dist = sample_graph().dijkstra("Hospital", "RailwayStn")
        self.assertEqual((path[0], path[-1], dist), ("Hospital", "RailwayStn", 10))

    def test_same_node_and_unreachable(self):
        g = sample_graph()
        g.add_road("Island", "Beach", 1)
        self.assertEqual(g.dijkstra("Stadium", "Stadium"), (["Stadium"], 0))
        self.assertIsNone(g.dijkstra("Hospital", "Island")[0])
        self.assertIsNone(g.dijkstra("Hospital", "Atlantis")[0])

    def test_invalid_and_duplicate_roads(self):
        g = Graph()
        for bad in (0, -1, math.nan, math.inf):
            with self.assertRaises(ValueError):
                g.add_road("A", "B", bad)
        with self.assertRaises(ValueError):
            g.add_road("A", "a", 1)
        g.add_road("A", "B", 1)
        with self.assertRaises(ValueError):
            g.add_road("b", "a", 2)

    def test_remove_road_and_resolve(self):
        g = sample_graph()
        self.assertEqual(g.resolve("hospital"), "Hospital")
        g.remove_road("Hospital", "CityPark")
        self.assertFalse(g.has_road("Hospital", "CityPark"))
        self.assertEqual(len(g.roads()), 6)
        with self.assertRaises(ValueError):
            g.remove_road("Hospital", "CityPark")


if __name__ == "__main__":
    unittest.main()
