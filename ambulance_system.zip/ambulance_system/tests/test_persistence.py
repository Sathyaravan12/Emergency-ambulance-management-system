import os
import tempfile
import unittest

from ems import persistence
from ems.errors import PersistenceError
from ems.models import EmergencyStatus
from ems.sample_data import load_demo
from ems.system import EmergencyAmbulanceSystem


def build():
    s = EmergencyAmbulanceSystem()
    load_demo(s, "small")
    for name, sev in [("A", 2), ("B", 1)]:
        s.register_emergency(name, 30, "9876543210", "Fall", "Stadium", sev)
    s.dispatch_next()                                    # B dispatched, A pending in the priority queue
    s.register_emergency("C", 40, "9876543210", "Burn", "Township", 3)   # still in the intake queue
    return s


class PersistenceTests(unittest.TestCase):
    def test_round_trip_preserves_everything(self):
        original = build()
        copy = EmergencyAmbulanceSystem()
        persistence.restore(copy, persistence.dump(original))
        self.assertEqual(persistence.dump(copy), persistence.dump(original))
        self.assertEqual([e.patient_name for e in copy.priority_snapshot()], ["A"])
        self.assertEqual([e.patient_name for e in copy.intake_snapshot()], ["C"])
        self.assertEqual(len(copy.dispatches), 1)

    def test_restored_system_keeps_working(self):
        copy = EmergencyAmbulanceSystem()
        persistence.restore(copy, persistence.dump(build()))
        self.assertEqual(copy.register_emergency("D", 5, "9876543210", "Fall", "Stadium", 1).id, 4)
        self.assertEqual(copy.dispatch_next().emergency.patient_name, "D")
        copy.complete_dispatch(2)                        # B, dispatched before the save
        self.assertIs(copy.find_emergency(2).status, EmergencyStatus.COMPLETED)

    def test_file_round_trip_and_missing_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "nested", "data.json")
            self.assertIsNone(persistence.load_json(path))
            persistence.save_json(path, {"hello": "world"})
            self.assertEqual(persistence.load_json(path), {"hello": "world"})
            self.assertEqual([f for f in os.listdir(os.path.dirname(path)) if f.endswith(".tmp")], [])

    def test_damaged_data_raises_clear_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "bad.json")
            with open(path, "w") as fh:
                fh.write("{not json")
            with self.assertRaises(PersistenceError):
                persistence.load_json(path)
        with self.assertRaises(PersistenceError):
            persistence.restore(EmergencyAmbulanceSystem(), {"version": 1})
        with self.assertRaises(PersistenceError):
            persistence.restore(EmergencyAmbulanceSystem(), {"version": 99})


class FailedRegistrationTests(unittest.TestCase):
    def test_failed_registration_does_not_consume_an_id(self):
        s = EmergencyAmbulanceSystem()
        load_demo(s, "small")
        with self.assertRaises(Exception):
            s.register_emergency("X", "bad age", "9876543210", "Fall", "Stadium", 1)
        self.assertEqual(s.register_emergency("Y", 30, "9876543210", "Fall", "Stadium", 1).id, 1)


if __name__ == "__main__":
    unittest.main()
