import unittest

from ems.cli import ConsoleApp, render_table
from ems.system import EmergencyAmbulanceSystem


def run_script(lines, system=None):
    system = system or EmergencyAmbulanceSystem()
    feed, output = iter(lines), []

    def fake_input(prompt=""):
        output.append(prompt)
        try:
            return next(feed)
        except StopIteration:
            raise EOFError from None

    ConsoleApp(system, input_fn=fake_input, output_fn=output.append, demo_dataset="small").run()
    return system, "\n".join(output)


class ConsoleTests(unittest.TestCase):
    def test_full_session(self):
        script = [
            "6",                                                     # load demo data
            "1", "1", "Cara", "30", "98765 43210", "Cardiac arrest", "stadium", "1", "0",   # register
            "4", "1", "0",                                           # dispatch next
            "5", "2", "0",                                           # dispatch history
            "4", "2", "1", "0",                                      # complete emergency #1
            "0",                                                     # exit
        ]
        system, out = run_script(script)
        self.assertIn("Emergency #1 registered for Cara (Critical)", out)
        self.assertIn("AMBULANCE DISPATCHED", out)
        self.assertIn("MallRoad -> Stadium", out)
        self.assertIn("Emergency #1 completed", out)
        self.assertEqual(system.stats()["completed"], 1)

    def test_invalid_input_is_reprompted_not_crashing(self):
        script = ["6", "1", "1", "Cara", "abc", "-4", "30", "bad", "9876543210", "Fall",
                  "Atlantis", "stadium", "7", "2", "0", "0", "0"]
        system, out = run_script(script)
        self.assertIn("Age must be a whole number", out)
        self.assertIn("Unknown location 'Atlantis'", out)
        self.assertIn("Enter 1 (critical)", out)
        self.assertEqual(len(system.emergencies), 1)

    def test_cancel_a_form_saves_nothing(self):
        system, out = run_script(["6", "1", "1", "Cara", "/cancel", "0", "0", "0"])
        self.assertIn("Cancelled. Nothing was saved.", out)
        self.assertEqual(len(system.emergencies), 0)

    def test_errors_and_bad_menu_choices_are_friendly(self):
        _, out = run_script(["9", "x", "4", "1", "0", "0"])          # dispatch with nothing set up
        self.assertIn("Please enter one of the numbers shown", out)
        self.assertIn("There are no pending emergencies", out)

    def test_end_of_input_exits_cleanly(self):
        _, out = run_script(["1"])
        self.assertIn("Goodbye.", out)

    def test_render_table(self):
        text = render_table(["A", "Long header"], [[1, "x"], [22, "yy"]])
        self.assertEqual(len(text.splitlines()), 4)
        self.assertTrue(text.splitlines()[1].startswith("-"))


if __name__ == "__main__":
    unittest.main()
