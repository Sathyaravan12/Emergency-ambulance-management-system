# Emergency Ambulance Management System Using Data Structures

A complete system for registering emergency calls, ranking them by severity, and dispatching
the nearest available ambulance along the shortest route. It has **two interfaces over one
backend**:

- a **web console** (front end in HTML/CSS, back end in Flask), and
- a **console application** (terminal menus, Python standard library only, as in the proposal).

All the real work is done by hand-written data structures and algorithms in the `ems/` package.
The core uses **no external libraries and no database**. Flask is needed only for the web interface.

**Student:** Sathya Murthy E. | **Register No.:** 26MCAB44 | **Programme:** MCA 'B', KJIT
**Course:** Data Structures and Algorithmic Techniques | **Guide:** Prof. Abinaya S

## Quick start

Requires Python 3.8 or newer.

```bash
# Console application (nothing to install)
python3 main.py --demo                    # 36-location city map and 10 ambulances
python3 main.py --demo --dataset small    # tiny 5-location map, easy to follow by hand

# Web application
pip install -r requirements.txt
python3 run_web.py            # then open http://127.0.0.1:5000
```

The first time the web app starts it creates the demo city map, ten ambulances and one
demo operator account:

| Username | Password |
|---|---|
| `admin` | `admin123` |

Create your own account from the **Create an account** link, and do not reuse the demo
password anywhere real.

## Demo data

The default demo is a **36-location road network of Bengaluru** (66 roads, approximate road kilometres) with
**10 ambulances** stationed at hospitals and suburbs:

- **North:** Yelahanka, Hebbal, Airport, Kothanur, Hennur, Banaswadi
- **East:** Indiranagar, Marathahalli, Whitefield, KR Puram, Bellandur, Manipal Hospital
- **Centre:** MG Road, Ulsoor, Shivajinagar, Bowring Hospital, Majestic, Malleshwaram, Yeshwanthpur, Rajajinagar, Vijayanagar
- **South:** Basavanagudi, Victoria Hospital, Jayanagar, JP Nagar, Banashankari, NIMHANS, Koramangala, St Johns Hospital, BTM Layout, HSR Layout, Silk Board, Bommanahalli, Electronic City, Narayana Health, Kengeri

Every location can reach every other. The 5-location `small` map is also included, which is handy for
checking Dijkstra by hand. Set `EMS_DEMO_DATASET=small` to seed the web app with it instead.
Add or remove your own roads at any time; a new road automatically creates any new locations.

## Architecture

```
  Browser (HTML / CSS)                 Terminal
        |                                 |
   webapp/  Flask routes, templates     main.py + ems/cli.py
        |                                 |
        +----------------+----------------+
                         |
                ems/system.py   <- all business rules and the dispatch workflow
                         |
   +---------------------+----------------------------+
   |                     |                            |
 structures.py       algorithms.py                graph.py
 LinkedList          linear_search               Graph (adjacency list)
 Queue               selection_sort              Dijkstra's algorithm
 MinHeap
 PriorityQueue
                         |
                 persistence.py  (optional JSON snapshot, used by the web app)
```

Both interfaces call the same `EmergencyAmbulanceSystem` class, so the console and the web
console behave identically.

## Data structures and algorithms

| Module | What it does | Structure / algorithm | Code |
|---|---|---|---|
| 1. Emergency registration | Records patient, emergency and location details; holds new requests in arrival order | **Queue** (FIFO, linked-list based) | `Queue` |
| 2. Priority management | Serves the most critical request first; equal severity is first come, first served | **Priority queue** on a binary **min-heap** | `PriorityQueue`, `MinHeap` |
| 3. Ambulance management | Registers, lists, removes and updates ambulance records dynamically | **Singly linked list**; **selection sort** for the fleet view | `LinkedList`, `selection_sort` |
| 4. Ambulance assignment | Finds the nearest available ambulance; finds records by id or name | **Linear search** | `linear_search`, `_nearest_available` |
| 5. Location and road management | Stores locations and the roads between them | **Graph** (weighted, undirected, adjacency list) | `Graph` |
| 6. Shortest route and dispatch | Computes the shortest route and updates statuses | **Dijkstra's algorithm** (greedy) with a min-heap | `Graph.dijkstra` |

Dijkstra's algorithm is not BFS: BFS counts hops, while Dijkstra minimises total road distance.

## Workflow

```
Register emergency -> Queue (intake)
        |
     Triage          -> Priority queue (by severity, then arrival)
        |
   Dispatch next:
     take the most critical request
        |
     linear search of the fleet -> nearest Available ambulance (Dijkstra distance)
        |
   found?  YES -> dispatch; ambulance becomes On Duty; route and distance recorded
           NO  -> request stays pending; the next request is tried
        |
   Complete dispatch -> ambulance is Available again
```

Triage runs automatically on dispatch, and can also be run on its own to watch the Queue and
Priority Queue work separately.

## Web console pages

| Page | What you can do |
|---|---|
| Overview | Live statistics, next requests in the queue, dispatches in progress, fleet status, one-click dispatch |
| Emergencies | Register a call (name, age, contact, type, location, severity); view the intake queue and priority queue; triage; cancel; dispatch |
| Records | All calls sorted by priority (selection sort); search by name or `#id` (linear search); cancel or complete |
| Fleet | Register, list (available first), remove and release ambulances |
| Road Map | Add and remove roads; network diagram; shortest-route finder that highlights the route and lists each leg |
| History | Every dispatch with route, distance and times; mark complete |

### How the road map is drawn

Small maps are drawn as a circle. Large maps use a **stress-majorization layout**: the distance between
two dots on screen follows the real road distance, so Yelahanka sits at the top, Narayana Health at the
bottom and Whitefield to the east. A second pass nudges crowded places apart so that no two labels overlap.
The layout is deterministic, so the same map always looks the same. Road lengths for a chosen route are
listed beside the map instead of being drawn on it.

## Console menus

`python3 main.py` offers the same capabilities through numbered menus (emergencies, ambulances,
road network, dispatch and routes, reports). Type `/cancel` at any prompt to abandon a form.

## Configuration (all optional)

| Variable | Purpose | Default |
|---|---|---|
| `EMS_DATA_FILE` | Where the web app saves its data and operator accounts | `instance/data.json` |
| `SECRET_KEY` | Session signing key | random key saved in `instance/secret.key` |
| `EMS_DEMO_DATASET` | Demo map for a brand-new web database: `city` or `small` | `city` |
| `HOST` / `PORT` | Web server address | `127.0.0.1` / `5000` |
| `FLASK_DEBUG` | `1` enables debug mode (development only) | off |

## Data storage

The proposal specifies no database, so the core keeps everything in memory. The web app adds a
small JSON file (`persistence.py`, standard library) so that data and accounts survive a restart.
Files are written atomically, so a crash cannot leave a half-written file. Delete
`instance/data.json` to reset the web app to the demo data. The console app is in-memory only.

## Project structure

```
ambulance_system/
├── main.py              Console application
├── run_web.py           Web application entry point
├── requirements.txt     Flask (web interface only)
├── ems/                 Backend (standard library only)
│   ├── structures.py    LinkedList, Queue, MinHeap, PriorityQueue
│   ├── algorithms.py    linear search, selection sort
│   ├── graph.py         Graph and Dijkstra's algorithm
│   ├── system.py        Business rules and the dispatch workflow
│   ├── persistence.py   JSON snapshots
│   ├── models.py        Emergency, Ambulance, DispatchRecord
│   ├── validators.py    Input validation
│   ├── errors.py        Exception types
│   ├── cli.py           Console menus
│   └── sample_data.py   Demo maps (36-location city, 5-location small) and fleets
├── webapp/              Web interface
│   ├── __init__.py      Application factory, security headers, error pages
│   ├── auth.py          Register, sign in, sign out, login throttling
│   ├── views.py         Console pages
│   ├── store.py         Thread-safe shared state and saving
│   ├── helpers.py       CSRF, login guard, map layout
│   ├── templates/       Jinja2 pages
│   └── static/          style.css, app.js
└── tests/               74 automated tests
```

## Design decisions

- **Unknown locations are rejected** at registration, so a typo cannot create a request nobody can reach.
  Names are matched ignoring case.
- **Unreachable requests never block the queue:** if no free ambulance can reach the top request, the
  next one is served and the skipped one stays pending.
- **One lock, one system:** all web requests share a single system guarded by a lock, so two operators
  can never be assigned the same ambulance.
- **Validation on the server** for every field (age 0-120, 7-15 digit contact number, positive road
  distances, unique vehicle numbers), in addition to the browser's own checks.

## Security

- Passwords are hashed; sessions are renewed on sign-in; repeated failed sign-ins are throttled.
- Every POST form carries a CSRF token, and sign-out is POST-only.
- All output is escaped. Confirmation prompts read their text from a `data-confirm` attribute, so
  patient names are never placed inside JavaScript.
- Security headers are set, and the secret key is never hard-coded.

## Testing

```bash
python3 -m unittest discover -s tests -v
```

74 tests cover each data structure (including deleting from the head, middle and tail of the linked
list), Dijkstra edge cases, the full register, triage, dispatch and complete workflow, input validation,
saving and restoring state, the 36-location demo (connected, clean, routable, no overlapping labels), authentication, CSRF, login throttling, output escaping, and scripted
console sessions.

## Complexity summary

| Operation | Cost |
|---|---|
| Queue enqueue / dequeue | O(1) |
| Linked list append / prepend / delete | O(1) / O(1) / O(n) |
| Priority queue push / pop | O(log n) |
| Linear search | O(n) |
| Selection sort | O(n²) |
| Dijkstra | O((V + E) log V) |

## Limitations and future work

- All signed-in operators have the same permissions (no admin and operator roles).
- The web app is built for a single server process. For production, run one worker behind a WSGI
  server with HTTPS.
- Roads are undirected and have no live traffic data.
- Possible extensions: GPS tracking, hospital capacity, live traffic weights, an interactive map.
