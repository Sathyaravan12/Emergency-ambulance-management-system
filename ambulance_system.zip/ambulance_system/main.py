"""
====================================================================
 EMERGENCY AMBULANCE MANAGEMENT SYSTEM USING DATA STRUCTURES
 Console application. Python standard library only; no database.
====================================================================
Student   : Sathya Murthy E.   |   Register# : 26MCAB44
Programme : MCA 'B'            |   Department: KJIT
Course    : Data Structures and Algorithmic Techniques
Guide     : Prof. Abinaya S
====================================================================
Run with:  python3 main.py                        (start empty)
           python3 main.py --demo                 (36-location city map and 10 ambulances)
           python3 main.py --demo --dataset small (tiny 5-location map)
Tests   :  python3 -m unittest discover -s tests -v
====================================================================
"""

import argparse

from ems.cli import ConsoleApp
from ems.sample_data import DATASETS, DEFAULT_DATASET, load_demo
from ems.system import EmergencyAmbulanceSystem


def main(argv=None):
    parser = argparse.ArgumentParser(description="Emergency Ambulance Management System")
    parser.add_argument("--demo", action="store_true", help="start with a demo road map and fleet")
    parser.add_argument("--dataset", choices=sorted(DATASETS), default=DEFAULT_DATASET,
                        help="which demo to load: 'city' (36 locations, default) or 'small' (5 locations)")
    args = parser.parse_args(argv)

    system = EmergencyAmbulanceSystem()
    if args.demo:
        load_demo(system, args.dataset)
    ConsoleApp(system, demo_dataset=args.dataset).run()


if __name__ == "__main__":
    main()
